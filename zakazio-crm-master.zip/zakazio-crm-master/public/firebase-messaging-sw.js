/*
/!* eslint-disable no-undef *!/
importScripts("https://www.gstatic.com/firebasejs/8.1.2/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.1.2/firebase-messaging.js");

// eslint-disable-next-line no-undef
firebase.initializeApp({
  apiKey: "AIzaSyB3oEdhcmf18rBVs0hPuv4FxpONIYATFJ0",
  authDomain: "zakazio-56c70.firebaseapp.com",
  databaseURL: "https://zakazio-56c70.firebaseio.com",
  projectId: "zakazio-56c70",
  storageBucket: "zakazio-56c70.appspot.com",
  messagingSenderId: "548924249412",
  appId: "1:548924249412:web:1f89dfcdd3b94df270b311",
  measurementId: "G-QKMNS00EG0"
});
firebase.messaging();
*/
