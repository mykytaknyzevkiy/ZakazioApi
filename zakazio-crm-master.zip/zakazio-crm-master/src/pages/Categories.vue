<template>
  <v-container>
    <Spinner />
    <v-row align="center">
      <v-col class="d-flex" cols="12" sm="6">
        <v-select
          label="Видимость"
          :items="[
            { text: 'да', value: 'true' },
            { text: 'нет', value: 'false' }
          ]"
          :value="activeFilters['onlyActives']"
          item-text="text"
          item-value="value"
          clearable
          @change="filterResults('onlyActives', $event)"
        />
      </v-col>
      <v-col class="d-flex" cols="12" sm="6">
        <v-select
          label="Количество на странице"
          :items="[10, 20, 30, 40, 50]"
          :value="activeFilters['size']"
          clearable
          @change="filterResults('size', $event)"
        />
      </v-col>
    </v-row>
    <v-card class="mb-5" flat>
      <v-card-title>
        <span>Категории – {{ categories.length }}</span>
        <v-spacer />
        <v-btn depressed small @click="createAction()">
          Создать
        </v-btn>
      </v-card-title>
      <v-divider />
      <template v-for="(category, key) in categories">
        <v-row :key="`user-${category.id}`" class="px-3">
          <v-col>
            <div class="caption grey--text">
              id
            </div>
            <div>
              {{ key + 1 }}
            </div>
          </v-col>
          <v-col>
            <div class="caption grey--text">
              Имя
            </div>
            <div>{{ category.name }}</div>
          </v-col>
          <v-col class="d-flex align-center">
            <span class="caption grey--text">
              {{ category.active ? "Показано" : "" }}
            </span>
          </v-col>
          <v-col class="d-flex align-center justify-end">
            <v-btn depressed small class="mr-3" @click="editAction(category)">
              редактировать
            </v-btn>
            <v-btn
              class="red--text"
              depressed
              small
              @click="deleteAction(category)"
            >
              удалить
            </v-btn>
          </v-col>
        </v-row>
        <v-divider
          v-if="key + 1 < categories.length"
          :key="`divider-${category.id}`"
        />
      </template>
    </v-card>
    <div class="text-center">
      <v-pagination
        :length="meta['maxPages']"
        :value="meta['pageNo']"
        @input="filterResults('page', $event)"
      />
    </div>
    <v-dialog v-model="DIALOG" max-width="500">
      <v-card>
        <v-card-title>{{ ACTIONS_ALIASES[ACTION] }}</v-card-title>
        <v-divider />
        <v-card-text class="pt-3">
          <template
            v-if="
              ACTION === ACTIONS.CREATE_ACTION || ACTION === ACTIONS.EDIT_ACTION
            "
          >
            <v-text-field v-model="FORM.name" label="Название" />
            <v-switch
              v-model="FORM.active"
              :true-value="true"
              :false-value="false"
              label="Видимость"
            />
          </template>
          <template v-else>
            <p class="d-flex align-center">
              Подтверждаете удаление?
            </p>
          </template>
        </v-card-text>
        <v-divider />

        <v-card-actions>
          <v-spacer />
          <v-btn
            v-if="ACTION === ACTIONS.CREATE_ACTION"
            depressed
            small
            @click="store()"
          >
            Сохранить
          </v-btn>
          <v-btn
            v-if="ACTION === ACTIONS.EDIT_ACTION"
            depressed
            small
            @click="update()"
          >
            Сохранить
          </v-btn>
          <v-btn
            v-if="ACTION === ACTIONS.DELETE_ACTION"
            depressed
            small
            @click="destroy()"
          >
            Удалить
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import helpers from "@/mixins/helpers";
import cruds from "@/mixins/cruds";
import filters from "@/mixins/filters";

const FORM = {
  id: null,
  name: "",
  active: false,
  image: null
};
export default {
  name: "Categories",
  mixins: [helpers, cruds, filters],
  data() {
    return {
      FORM,
      meta: {
        maxPages: 0,
        pageNo: 1
      },
      categories: []
    };
  },
  created() {
    this.startLoading();
    this.loadData();
  },
  methods: {
    loadData() {
      this.$axios
        .get("category/list", { params: this.activeFilters })
        .then(response => {
          this.categories = response.data.data.items;
          this.meta = {
            maxPages: response.data.data.maxPages,
            pageNo: response.data.data.pageNo
          };
          this.stopLoading();
        })
        .catch(error => {
          // TODO: возвращать 404
          console.log(error.response.status);
          this.stopLoading();
        });
    },
    resetForm() {
      this.FORM = { ...FORM };
    },
    createAction() {
      this.ACTION = this.ACTIONS.CREATE_ACTION;
      this.DIALOG = true;
    },
    editAction(category) {
      this.ACTION = this.ACTIONS.EDIT_ACTION;
      this.FORM = { ...category };
      this.DIALOG = true;
    },
    deleteAction(category) {
      this.ACTION = this.ACTIONS.DELETE_ACTION;
      this.FORM = { ...category };
      this.DIALOG = true;
    },
    store() {
      this.$axios.post("category/create/", this.FORM).then(async () => {
        await this.startLoading();
        await this.loadData();
        this.DIALOG = false;
      });
    },
    update() {
      this.$axios
        .put(`category/update/${this.FORM.id}`, this.FORM)
        .then(async () => {
          await this.startLoading();
          await this.loadData();
          this.DIALOG = false;
        });
    },
    destroy() {
      this.$axios.delete(`category/delete/${this.FORM.id}`).then(async () => {
        await this.startLoading();
        await this.loadData();
        this.DIALOG = false;
      });
    }
  }
};
</script>
