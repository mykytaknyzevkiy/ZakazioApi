<template>
  <v-card flat class="mx-auto">
    <v-card-title v-if="STEP === STEPS.SELECT" class="d-flex flex-column px-0">
      <p class="font-weight-bold">выбирите роль</p>
      <v-btn
        class="mb-5"
        color="primary"
        outlined
        block
        x-large
        @click="(TARGET = TARGETS.CLIENT) && (STEP = STEPS.PHONE)"
        ><v-icon>mdi-account-tie</v-icon> Как клиент</v-btn
      >
      <v-btn
        class="mb-5"
        color="primary"
        outlined
        block
        x-large
        @click="(TARGET = TARGETS.PARTNER) && (STEP = STEPS.PHONE)"
        ><v-icon>mdi-handshake</v-icon> Как партнер</v-btn
      >
      <v-btn
        class="mb-5"
        color="primary"
        outlined
        block
        x-large
        @click="(TARGET = TARGETS.EXECUTOR) && (STEP = STEPS.PHONE)"
        ><v-icon>mdi-shovel</v-icon> Как исполнитель</v-btn
      >
    </v-card-title>
    <register-form
      v-else
      :errors="ERRORS"
      :steps="STEPS"
      :step="STEP"
      :progress="progress"
      @registerPhone="registerPhone($event)"
      @registerSMS="registerSMS($event)"
      @register="register($event)"
      @resetProcess="clearProcessInfo"
    />
  </v-card>
</template>

<script>
import RegisterForm from "@/components/Register/RegisterForm";
import Bus from "@/main";
import { hasProp } from "@/helpers/helpers";
const TARGETS = {
  CLIENT: "CLIENT",
  PARTNER: "PARTNER",
  EXECUTOR: "EXECUTOR"
};
const STEPS = {
  SELECT: "STEP_SELECT",
  PHONE: "STEP_PHONE",
  SMS: "STEP_SMS",
  FINISH: "STEP_FINISH",
  DONE: "STEP_DONE"
};
const ERRORS_LIST = [
  {
    message: "Already taken",
    text: "Пользователь с таким номером телефона уже зарегистрирован.",
    field: "phoneNumber"
  },
  {
    message: "No answer",
    text: "Нет ответа от сервера.",
    field: "phoneNumber"
  },
  {
    message: "Wrong password",
    text: "Неверный смс-код.",
    field: "smsCode"
  },
  {
    message: "Already taken",
    text: "Пользователь с таким email-ом уже зарегистрирован.",
    field: "email"
  }
];
export default {
  name: "Register",
  components: { RegisterForm },
  data() {
    return {
      TARGETS: { ...TARGETS },
      TARGET: TARGETS.CLIENT,
      STEP: STEPS.SELECT,
      STEPS: { ...STEPS },
      ERRORS: [],
      errorMessage: "",
      disabledSwitch: false,
      registerError: false,
      progress: 0
    };
  },
  async beforeRouteLeave(to, from, next) {
    await this.clearProcessInfo();
    next();
  },
  mounted() {
    this.getProcessInfo();
  },
  methods: {
    getProcessInfo() {
      const info = JSON.parse(window.localStorage.getItem("PROCESS_INFO"));
      if (info !== null) {
        Bus.$emit("setFormData", {
          phoneNumber: info.PHONE_NUMBER,
          token: info.TOKEN
        });
        this.TARGET = info.TARGET ? this.TARGETS[info.TARGET] : TARGETS.CLIENT;
        this.STEP = info.STEP || STEPS.SELECT;
        if (this.STEP !== STEPS.SELECT) {
          this.disabledSwitch = true;
        }
      }
    },
    setProcessInfo(key, value) {
      let info = {
        PHONE_NUMBER: "",
        EXPIRATION: "",
        TARGET: "",
        STEP: "",
        TOKEN: ""
      };
      if (window.localStorage.getItem("PROCESS_INFO") !== null) {
        info = {
          ...info,
          ...JSON.parse(window.localStorage.getItem("PROCESS_INFO"))
        };
      }
      if (typeof key === "object") {
        info = { ...info, ...key };
      } else {
        info[key] = value;
      }

      window.localStorage.setItem("PROCESS_INFO", JSON.stringify(info));
    },
    clearProcessInfo() {
      const info = {
        PHONE_NUMBER: "",
        EXPIRATION: "",
        TARGET: "",
        STEP: "",
        TOKEN: ""
      };
      window.localStorage.setItem("PROCESS_INFO", JSON.stringify(info));
      this.STEP = STEPS.PHONE;
      this.TARGET = TARGETS.CLIENT;
      this.disabledSwitch = false;
      Bus.$emit("setFormData", {
        phoneNumber: "",
        token: ""
      });
    },
    initProgress(exp) {
      const interval = setInterval(() => {
        if (Math.floor(Date.now() / 1000) > exp) {
          return clearInterval(interval);
        }
        this.progress++;
      }, 600);
    },
    async setStep(value) {
      await this.setProcessInfo("STEP", value);
      this.STEP = value;
    },
    async registerPhone(formData) {
      this.disabledSwitch = true;
      this.ERRORS = [];
      this.$axios
        .post(`${this.TARGET.toLowerCase()}/register/phone`, formData)
        .then(async response => {
          this.STEP = STEPS.SMS;
          this.setProcessInfo({
            TOKEN: response.data.data.token,
            PHONE_NUMBER: formData.phoneNumber,
            TARGET: TARGETS.CLIENT,
            EXPIRATION: Math.floor(Date.now() / 1000) + 60,
            STEP: STEPS.SMS
          });
          return Bus.$emit("clientRegisterPhoneDone", response.data);
        })
        .catch(async error => {
          const responseError = hasProp(error, "response")
            ? error.response.data.error
            : "No answer";
          await this.errorCollector(responseError, "phoneNumber");
          return Bus.$emit("clientRegisterPhoneFailed");
        });
    },
    async registerSMS(formData) {
      this.ERRORS = [];
      this.$axios
        .post(`${this.TARGET.toLowerCase()}/register/phone`, formData)
        .then(response => {
          this.STEP = STEPS.FINISH;
          this.setProcessInfo({
            TOKEN: response.data.data.token,
            STEP: STEPS.FINISH
          });
          Bus.$emit("clientRegisterSMSDone", response.data);
        })
        .catch(error => {
          this.errorCollector(error.response.data.error, "smsCode");
          Bus.$emit("clientRegisterSMSFailed");
        });
    },

    async register(formData) {
      const data = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        middleName: formData.middleName,
        email: formData.email,
        password: formData.password
      };
      try {
        await this.$axios.post(`${this.TARGET.toLowerCase()}/register`, data, {
          headers: {
            token: formData.token
          }
        });
        this.STEP = STEPS.DONE;
        this.setProcessInfo({
          STEP: STEPS.PHONE,
          PHONE: "",
          EXP: "",
          TARGET: "",
          PHONE_NUMBER: ""
        });
        Bus.$emit("clientRegisterDone");
      } catch (error) {
        this.errorCollector(error.response.data.error, "email");
      }
    },
    errorCollector(message, field) {
      this.ERRORS.push(
        ERRORS_LIST.find(
          error => error.message === message && error.field === field
        )
      );
    },
    setErrorMessage(status) {
      if (status === 400) {
        this.errorMessage = "Пользователь с таким email уже зарегистрирован!";
      }
    }
  }
};
</script>

<style scoped></style>
