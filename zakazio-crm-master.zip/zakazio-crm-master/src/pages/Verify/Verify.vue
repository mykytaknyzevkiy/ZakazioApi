<template>
  <v-container class="fill-height d-flex align-center justify-center">
    <router-view />
  </v-container>
</template>
