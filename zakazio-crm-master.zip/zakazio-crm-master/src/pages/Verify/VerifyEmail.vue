<template>
  <v-card flat max-width="800" width="100%">
    <v-card-title>Подтверждение Email</v-card-title>
    <v-divider />
    <v-card-text>
      <template v-if="userData.emailActive === false">
        <v-alert v-if="step === 0" class="mb-6" dense outlined type="error">
          Ваш email <strong>{{ userData.email }}</strong> еще не подтвержден.
        </v-alert>
        <v-alert
          v-if="step === 1"
          class="mb-6"
          dense
          outlined
          color="grey"
          type="error"
        >
          На ваш email <strong>{{ userData.email }}</strong> отправлен
          проверочный код. Введите его.
        </v-alert>
        <template v-if="step === 2">
          <v-alert class="mb-6" dense outlined color="green">
            Ваш email <strong>{{ userData.email }}</strong> подтвержден.
          </v-alert>
          <v-btn to="/profile" depressed>Перейти к профилю</v-btn>
        </template>

        <v-form v-if="step === 0" class="mb-4" @submit.prevent="toCode">
          <v-btn depressed class="primary" type="submit">Подтвердить</v-btn>
        </v-form>
        <v-form v-if="step === 1" class="mb-4" @submit.prevent="complete">
          <v-text-field
            v-model="FORM.code"
            prepend-inner-icon="mdi-email-alert-outline"
            outlined
            label="Проверочный код"
          ></v-text-field>
          <v-btn
            depressed
            class="primary"
            type="submit"
            :disabled="FORM.code === ''"
            >Завершить</v-btn
          >
        </v-form>
        <v-stepper class="elevation-0" :value="step">
          <v-stepper-header>
            <v-stepper-step
              color="green"
              class="pl-0"
              :complete="step > 0"
              step="1"
            >
              Получите проверочный код
            </v-stepper-step>
            <v-divider />
            <v-stepper-step
              color="green"
              class="pr-0"
              :complete="step > 1"
              step="2"
            >
              Подтвердите email
            </v-stepper-step>
          </v-stepper-header>
        </v-stepper>
      </template>
      <template v-else>
        <v-alert dense text type="success"
          >Ваш email <strong>{{ userData.email }}</strong> уже
          подтвержден.</v-alert
        >
        <v-btn to="/profile" depressed>Перейти к профилю</v-btn>
      </template>
    </v-card-text>
  </v-card>
</template>

<script>
import { mapGetters } from "vuex";

const FORM = {
  token: null,
  code: ""
};
export default {
  name: "VerifyPhone",
  data() {
    return {
      FORM,
      step: 0
    };
  },
  computed: {
    ...mapGetters(["userData"])
  },
  methods: {
    toCode() {
      this.$axios
        .put("/user/active/email", { email: this.userData.email })
        .then(r => {
          this.FORM.token = r.data.data.token;
          this.step = 1;
        });
    },
    complete() {
      this.$axios.put("/user/active/email", { ...this.FORM }).then(r => {
        this.step = 2;
      });
    }
  }
};
</script>
