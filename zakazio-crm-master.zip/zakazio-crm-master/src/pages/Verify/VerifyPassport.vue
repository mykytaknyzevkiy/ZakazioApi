<template>
  <v-card flat max-width="800" width="100%">
    <v-card-title>Паспорт</v-card-title>
    <v-divider />
    <v-card-text>
      <template v-if="step === 0">
        <v-alert class="mb-6" dense outlined type="error">
          Вы еще не добавили свой паспорт.
        </v-alert>
        <v-btn depressed class="primary" type="submit" @click="step = 1"
          >Добавить</v-btn
        >
      </template>
      <v-form
        v-if="step === 1"
        ref="form"
        class="mb-4"
        @submit.prevent="submit"
      >
        <v-row>
          <v-col>
            <v-text-field
              v-model="FORM.serial"
              outlined
              label="Серия паспорта"
              placeholder="XXXX"
              hide-details
              maxlength="4"
              :rules="[v => !!v || '']"
            ></v-text-field>
          </v-col>
          <v-col>
            <v-text-field
              v-model="FORM.number"
              outlined
              label="Номер паспорта"
              placeholder="XXXXXX"
              hide-details
              maxlength="6"
              :rules="[v => !!v || '']"
            ></v-text-field>
          </v-col>
        </v-row>
        <v-row>
          <v-col>
            <v-menu
              v-model="calendar"
              :close-on-content-click="false"
              offset-y
              max-width="290"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  :value="FORM.date_begin"
                  readonly
                  prepend-inner-icon="mdi-calendar"
                  hide-details
                  label="Дата выдачи"
                  outlined
                  v-bind="attrs"
                  clearable
                  :rules="[v => !!v || '']"
                  v-on="on"
                />
              </template>
              <v-date-picker
                locale="ru"
                @click:date="(FORM.date_begin = $event) && (calendar = false)"
              />
            </v-menu>
            {{ FORM.date_begin }}
          </v-col>
          <v-col>
            <v-text-field
              v-model="FORM.taxID"
              outlined
              hide-details
              label="ИП"
              placeholder="XXXXXXXXXX"
              :rules="[v => !!v || '']"
            />
          </v-col>
        </v-row>

        <v-row>
          <v-col>
            <v-file-input
              v-model="FORM.passportOne"
              prepend-icon=""
              prepend-inner-icon="mdi-paperclip"
              hide-details
              outlined
              label="Копия паспорта"
              :rules="[v => !!v || '']"
            />
          </v-col>
          <v-col>
            <v-file-input
              v-model="FORM.passportTwo"
              prepend-icon=""
              prepend-inner-icon="mdi-paperclip"
              hide-details
              outlined
              label="Копия паспорта (обратная сторона)"
              :rules="[v => !!v || '']"
            />
          </v-col>
        </v-row>
        <v-row>
          <v-col>
            <v-btn :loading="loading" depressed class="primary" type="submit"
              >Сохранить</v-btn
            >
          </v-col>
        </v-row>
      </v-form>
      <template v-else-if="step === 2">
        <v-alert dense text type="success"
          >Ваш паспорт в очереди на обработку</v-alert
        >
        <v-btn to="/profile" depressed>Перейти к профилю</v-btn>
      </template>
    </v-card-text>
  </v-card>
</template>

<script>
import getBase64 from "@/helpers/getBase64";
import { mapGetters } from "vuex";

const FORM = {
  serial: "",
  number: "",
  date_begin: "",
  taxID: "",
  passportOne: null,
  passportTwo: null
};
export default {
  name: "VerifyPassport",
  data() {
    return {
      FORM,
      calendar: false,
      step: 0,
      loading: false
    };
  },
  computed: {
    ...mapGetters(["userData"])
  },
  methods: {
    getBase64,
    async submit() {
      if (!this.$refs.form.validate()) {
        return false;
      }
      this.loading = true;
      const passportOne = await getBase64(this.FORM.passportOne).then(r =>
        r.replace(/^data:image\/[a-z]+;base64,/, "")
      );
      const passportTwo = await getBase64(this.FORM.passportTwo).then(r =>
        r.replace(/^data:image\/[a-z]+;base64,/, "")
      );
      // eslint-disable-next-line camelcase
      const { serial, number, date_begin, taxID } = this.FORM;
      this.$axios
        .post("/passport/request/add", {
          serial,
          number,
          date_begin,
          taxID,
          files: [passportOne, passportTwo]
        })
        .then(r => {
          this.loading = false;
          this.step = 2;
        });
    }
  }
};
</script>
