<template>
  <v-container>
    <spinner />

    <!--    <v-row class="px-0">
      <v-col class="col-12 col-md-4">
        <v-text-field
          hide-details="auto"
          outlined
          placeholder="Поиск"
          label="Поиск"
          clearable
          :value="activeFilters.search"
          @click:clear="filterResults('search', '')"
          @keydown.enter="filterResults('search', $event.target.value)"
        />
      </v-col>
    </v-row>-->

    <v-card class="mb-5 mx-auto" flat>
      <v-card-title>
        <span>Люди – {{ users.length }}</span>
        <span class="ml-1 mr-auto font-weight-light body-1" />
        <v-spacer />
        <v-btn
          v-if="currentEntity !== 'partners'"
          depressed
          color="primary"
          @click="createAction"
          >Добавить
        </v-btn>
      </v-card-title>
      <v-divider />
      <template v-for="(user, key) in users">
        <router-link
          :key="`user-${user.id}`"
          class="row-link"
          :to="`/users/${user.id}`"
        >
          <v-row class="px-3">
            <v-col class="col-12 col-md-1">
              <div class="caption grey--text">
                id
              </div>
              <div>
                {{ key + 1 }}
              </div>
            </v-col>
            <v-col class="col-12 col-md-1">
              <v-avatar color="red">
                <img
                  v-if="user.avatar"
                  height="60"
                  :src="storageUrl + '/' + user.avatar"
                  :alt="user.avatar"
                />
                <span v-else class="white--text headline"
                  >{{ user.firstName[0] }} {{ user.lastName[0] }}</span
                >
              </v-avatar>
            </v-col>

            <v-col class="col-4 col-md-2">
              <div class="caption grey--text">
                Имя
              </div>
              <div>{{ user.firstName }}</div>
            </v-col>
            <v-col class="col-4 col-md-2">
              <div class="caption grey--text">
                Фамилия
              </div>
              <div>{{ user.lastName }}</div>
            </v-col>
            <v-col class="col-4 col-md-2">
              <div class="caption grey--text">
                Отчество
              </div>
              <div>{{ user.middleName }}</div>
            </v-col>
            <v-col
              v-if="
                $route.path === '/executors' ||
                  $route.path === '/clients' ||
                  $route.path === '/partners'
              "
              class="col-6 col-md-2"
            >
              <div class="caption grey--text">
                Заказов
              </div>
              <div>
                Законченных: {{ user.order.count.close }} <br />
                В работе:
                {{ user.order.count.open }}
              </div>
            </v-col>
            <v-col
              v-if="$route.path === '/executors' || $route.path === '/clients'"
              class="col-6 col-md-2"
            >
              <div class="caption grey--text">
                Рейтинг
              </div>
              <div>
                {{ user.rate }}
              </div>
            </v-col>

            <!--<v-col class="col-auto">
              <v-btn
                class="mr-5"
                small
                depressed
                @click.prevent="editAction(user)"
              >
                Редактировать
              </v-btn>
              <v-btn
                color="error"
                small
                depressed
                @click.prevent="deleteAction(user)"
              >
                Удалить
              </v-btn>
            </v-col>-->
          </v-row>
        </router-link>

        <v-divider v-if="key + 1 < users.length" :key="`divider-${user.id}`" />
      </template>
      <template v-if="users.length === 0">
        <no-content />
      </template>
    </v-card>
    <div class="text-center">
      <v-pagination
        :length="pageable['totalPages']"
        :value="pageable['pageNumber']"
        @input="filterResults('page', $event)"
      />
    </div>
    <v-dialog v-model="addUserDialog" max-width="600">
      <v-card>
        <v-form
          ref="userForm"
          lazy-validation
          @submit.prevent="
            ACTION === ACTIONS.ADD
              ? store()
              : ACTION === ACTIONS.EDIT
              ? update()
              : destroy()
          "
        >
          <v-card-text class="pa-5">
            <template v-if="ACTION !== ACTIONS.DELETE">
              <v-text-field
                v-model="USER_FORM.firstName"
                class="mb-5"
                outlined
                label="Имя"
                hide-details="auto"
                placeholder="Николай"
                :rules="[v => !!v || '']"
              />
              <v-text-field
                v-model="USER_FORM.lastName"
                class="mb-5"
                outlined
                label="Фамилия"
                hide-details="auto"
                placeholder="Козлов"
                :rules="[v => !!v || '']"
              />
              <v-text-field
                v-model="USER_FORM.middleName"
                class="mb-5"
                outlined
                label="Отчество"
                hide-details="auto"
                placeholder="Сергеевич"
                :rules="[v => !!v || '']"
              />
              <v-text-field
                v-model="USER_FORM.phoneNumber"
                class="mb-5"
                outlined
                label="Телефон"
                hide-details="auto"
                placeholder="+79520650966"
                :rules="[v => !!v || '']"
              />
              <v-text-field
                v-model="USER_FORM.email"
                class="mb-5"
                outlined
                label="Email"
                hide-details="auto"
                placeholder="example@email.com"
                :rules="[v => !!v || '', v => /.+@.+\..+/.test(v) || '']"
              />
              <v-text-field
                v-model="USER_FORM.password"
                outlined
                label="Пароль"
                type="password"
                hide-details="auto"
                placeholder="*****"
                :rules="[v => !!v || '']"
              /> </template
          ></v-card-text>
          <v-divider />
          <v-card-actions class="pa-5">
            <v-btn
              type="submit"
              :class="ACTION !== ACTIONS.DELETE ? 'primary' : 'error'"
              depressed
              >{{
                ACTION === ACTIONS.ADD
                  ? "Сохранить"
                  : ACTION === ACTIONS.EDIT
                  ? "Сохранить"
                  : "Удалить"
              }}
            </v-btn>
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import Spinner from "@/components/Spinner";
import ROLES from "@/constants/roles";
import NoContent from "@/components/NoContent";
import ACTIONS from "@/constants/acitions";
const USER_FORM = {
  id: null,
  firstName: "",
  lastName: "",
  middleName: "",
  email: "",
  phoneNumber: "",
  password: ""
};

export default {
  name: "Users",
  components: { NoContent, Spinner },
  data() {
    return {
      ACTIONS: ACTIONS,
      ACTION: ACTIONS.NO,
      addUserDialog: false,
      activeFilters: {
        page: "1",
        search: ""
      },
      ROLES: { ...ROLES },
      users: [],
      USER_FORM,
      pageable: {
        offset: 0,
        pageNumber: 0,
        pageSize: 0,
        paged: true,
        unpaged: false,
        totalElements: 0,
        totalPages: 0
      }
    };
  },
  computed: {
    currentEntity() {
      return this.$route.path.substring(1, this.$route.path.length);
    }
  },
  watch: {
    "$route.path": async function() {
      // this.activeFilters = { ...this.activeFilters, ...this.$route.query };
      this.users = [];
      await this.startLoading();
      await this.loadData();
    }
  },
  async created() {
    this.activeFilters = { ...this.$route.query };
    await this.startLoading();
    await this.loadData();
  },
  methods: {
    createAction() {
      this.addUserDialog = true;
      this.ACTION = ACTIONS.ADD;
      this.USER_FORM = { ...USER_FORM };
    },
    editAction(user) {
      const { id, firstName, lastName, middleName, email, phoneNumber } = user;
      this.USER_FORM = {
        id,
        firstName,
        lastName,
        middleName,
        email,
        phoneNumber
      };
      this.addUserDialog = true;
      this.ACTION = ACTIONS.EDIT;
    },
    deleteAction(user) {
      this.ACTION = ACTIONS.DELETE;
      this.addUserDialog = true;
      this.USER_FORM.id = user.id;
    },
    store() {
      const currentEntity = this.$route.path.substring(
        1,
        this.$route.path.length - 1
      );
      if (this.$refs.userForm.validate()) {
        this.$axios
          .post(`${currentEntity}/add`, this.USER_FORM)
          .then(async () => {
            this.ACTION = ACTIONS.NO;
            this.USER_FORM = { ...USER_FORM };
            this.addUserDialog = false;
            await this.$refs.userForm.resetValidation();
            await this.startLoading();
            await this.loadData();
            await this.stopLoading();
          });
      }
    },
    destroy() {
      const currentEntity = this.$route.path.substring(
        1,
        this.$route.path.length - 1
      );
      if (this.$refs.userForm.validate()) {
        this.$axios
          .delete(`${currentEntity}/${this.USER_FORM.id}`)
          .then(async () => {
            this.ACTION = ACTIONS.NO;
            this.USER_FORM = { ...USER_FORM };
            this.addUserDialog = false;
            await this.$refs.userForm.resetValidation();
            await this.startLoading();
            await this.loadData();
            await this.stopLoading();
          });
      }
    },
    async filterResults(prop, value) {
      const tValue = value.toString();
      if (prop !== "page") {
        this.activeFilters.page = "1";
      }
      this.activeFilters[prop] = tValue;
      if (this.$route.query[prop] !== tValue) {
        await this.$router.replace({
          query: {
            ...this.activeFilters
          }
        });
      }

      await this.startLoading();
      await this.loadData();
    },
    loadData() {
      this.$axios
        .get(`${this.$route.meta.type}/list`, {
          params: {
            ...this.activeFilters,
            page: (Number(this.activeFilters.page) - 1).toString()
          }
        })
        .then(response => {
          this.stopLoading();
          this.users = [...response.data.data.content];
          const {
            offset,
            pageNumber,
            pageSize,
            paged,
            unpaged
          } = response.data.data.pageable;
          this.pageable = {
            ...this.pageable,
            offset,
            pageNumber: pageNumber + 1,
            pageSize,
            paged,
            unpaged,
            totalElements: response.data.data.totalElements,
            totalPages: response.data.data.totalPages
          };
        })
        .catch(() => this.stopLoading());
    }
  }
};
</script>

<style scoped lang="scss">
.row-link {
  text-decoration: none;
}
</style>
