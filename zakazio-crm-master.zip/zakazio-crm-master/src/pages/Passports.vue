<template>
  <v-container>
    <Spinner />
    <v-card max-width="800" class="mb-5 mx-auto" flat>
      <v-card-title>
        <span>Паспорта</span>
      </v-card-title>
      <v-divider />
      <template v-for="passport in requests">
        <v-row :key="`passport-${passport.id}`" class="px-3">
          <v-col>
            <div class="text-caption grey--text">Пользователь</div>
            <div>
              {{ passport.user.firstName + " " + passport.user.lastName }}
            </div>
          </v-col>
          <v-col>
            <div class="text-caption grey--text">Дата</div>
            <div>{{ passport.date_begin }}</div>
          </v-col>
          <!--          <v-col>
            <div class="text-caption grey&#45;&#45;text">Статус</div>
            <div class="d-flex align-center">
              <v-icon color="orange" class="mr-1">mdi-timer-sand</v-icon>
              <v-icon color="green" class="mr-1">mdi-check-decagram</v-icon>
              <v-icon color="red" class="mr-1">mdi-close-circle</v-icon>
              <span>Ожидает подтверждения</span>
            </div>
          </v-col>-->
          <v-col class="d-flex align-center">
            <v-btn depressed class="primary" @click="viewRequest(passport)"
              >Действия
            </v-btn>
          </v-col>
        </v-row>
        <v-divider :key="`divider-${passport.id}`" />
      </template>
      <template v-if="requests.length === 0">
        <no-content />
      </template>
    </v-card>
    <v-dialog v-model="actionDialog" max-width="600">
      <v-card v-if="Object.keys(request).length > 0" flat>
        <v-card-title>
          {{ `${request.user.firstName} ${request.user.lastName}` }}
        </v-card-title>
        <v-divider />
        <v-card-text class="pa-3">
          <v-row>
            <v-col class="col-4"
              ><v-text-field
                readonly
                filled
                label="Серия"
                :value="request.serial"
            /></v-col>
            <v-col class="col-8">
              <v-text-field
                readonly
                filled
                label="Номер"
                :value="request.number"
            /></v-col>
          </v-row>
          <v-row>
            <v-col
              ><v-text-field
                readonly
                filled
                label="Дата выдачи"
                :value="request.date_begin"
            /></v-col>
            <v-col>
              <v-text-field readonly filled label="ИП" :value="request.taxID"
            /></v-col>
          </v-row>
          <v-row>
            <v-col>
              <v-card>
                <v-img
                  aspect-ratio="1"
                  contain
                  class="grey darken-4"
                  :src="`${storageUrl}/${request.files[0]}`"
                />
              </v-card>
            </v-col>
            <v-col>
              <v-card>
                <v-img
                  contain
                  aspect-ratio="1"
                  class="grey darken-4"
                  :src="`${storageUrl}/${request.files[1]}`"
                />
              </v-card>
            </v-col>
          </v-row>
        </v-card-text>
        <v-divider />
        <v-card-actions class="pa-4">
          <v-spacer />
          <v-btn
            depressed
            class="red white--text"
            :loading="loading"
            @click="refuseRequest(request.id)"
            >Отклонить</v-btn
          >
          <v-btn
            depressed
            class="primary"
            :loading="loading"
            @click="acceptRequest(request.id)"
            >Одобрить</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import filters from "@/mixins/filters";
import NoContent from "@/components/NoContent";

export default {
  name: "Passports",
  components: { NoContent },
  mixins: [filters],
  data() {
    return {
      actionDialog: false,
      requests: [],
      request: {},
      loading: false
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    viewRequest(passport) {
      this.request = { ...passport };
      this.actionDialog = true;
    },
    loadData() {
      this.$axios.get("/passport/request/list").then(r => {
        this.requests = r.data.data.content;
      });
    },
    acceptRequest(id) {
      this.loaading = true;
      this.$axios.put(`/passport/request/${id}/accept`).then(async () => {
        this.loading = false;
        this.actionDialog = false;
        await this.startLoading();
        await this.loadData();
        await this.stopLoading();
      });
    },
    refuseRequest(id) {
      this.loaading = true;
      this.$axios.put(`/passport/request/${id}/refuse`).then(async () => {
        this.loading = false;
        this.actionDialog = false;
        await this.startLoading();
        await this.loadData();
        await this.stopLoading();
      });
    }
  }
};
</script>
