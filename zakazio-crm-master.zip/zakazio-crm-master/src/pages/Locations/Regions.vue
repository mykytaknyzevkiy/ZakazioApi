<template>
  <v-container>
    <Spinner />
    <v-card max-width="800" class="mb-5 mx-auto" flat>
      <v-card-title>
        <span>Регионы</span>
        <v-spacer />
        <v-btn depressed @click="addAction">Добавить</v-btn>
      </v-card-title>
      <v-divider />
      <template v-for="(region, index) in content">
        <v-row :key="region.id" class="px-5">
          <v-col class="col-auto col-4">
            <span class="d-block text-caption grey--text">Регион</span>
            <span class="d-block font-weight-medium">{{ region.name }}</span>
          </v-col>
          <v-col class="d-flex align-center">
            <v-chip x-small outlined label>{{ region.code }} </v-chip>
          </v-col>
          <v-spacer />
          <v-col class="d-flex justify-end">
            <v-btn icon class="mr-3" @click="editAction(region)">
              <v-icon>mdi-playlist-edit</v-icon>
            </v-btn>
            <!--            <v-btn icon class="mr-3" @click="deleteAction(region)">
              <v-icon>mdi-playlist-remove</v-icon>
            </v-btn>-->
            <v-btn
              depressed
              small
              :to="{ name: 'Cities', params: { id: region.id } }"
            >
              <v-icon size="18">mdi-map-marker-multiple</v-icon>
              Города
            </v-btn>
          </v-col>
        </v-row>
        <v-divider
          v-show="index + 1 < content.length"
          :key="`dvdr-${region.id}`"
        />
      </template>
    </v-card>
    <div class="text-center">
      <v-pagination
        :length="pageable['totalPages']"
        :value="pageable['pageNumber']"
        @input="filterResults('page', $event)"
      />
    </div>
    <v-dialog v-model="DIALOG" max-width="600">
      <v-card>
        <v-card-title
          >{{
            ACTION === ACTIONS.ADD
              ? "Создание"
              : ACTION === ACTIONS.EDIT
              ? "Редактирование"
              : "Удаление"
          }}
        </v-card-title>
        <v-divider />
        <v-form
          ref="form"
          @submit.prevent="
            ACTION === ACTIONS.ADD
              ? store()
              : ACTION === ACTIONS.EDIT
              ? update()
              : destroy()
          "
        >
          <v-card-text class="pa-5">
            <template v-if="ACTION !== ACTIONS.DELETE">
              <v-text-field
                v-model="FORM.name"
                class="mb-5"
                hide-details="auto"
                label="Название региона"
                outlined
                dense
                placeholder=" "
                :rules="[v => !!v || '']"
              />
              <v-text-field
                v-model="FORM.postCode"
                hide-details="auto"
                label="Почтовый код"
                outlined
                dense
                placeholder=" "
                type="number"
                :rules="[v => !!v || '']"
              />
            </template>
            <template v-else>
              <div>
                Подтверждаете удаление?
              </div>
            </template>
          </v-card-text>
          <v-divider />
          <v-card-actions class="pa-5">
            <v-btn
              type="submit"
              :class="ACTION !== ACTIONS.DELETE ? 'primary' : 'error'"
              depressed
              >{{
                ACTION === ACTIONS.ADD
                  ? "Сохранить"
                  : ACTION === ACTIONS.EDIT
                  ? "Сохранить"
                  : "Удалить"
              }}
            </v-btn>
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import queries from "@/mixins/queries";
import ACTIONS from "@/constants/acitions";

const FORM = {
  id: null,
  name: "",
  postCode: ""
};
export default {
  name: "Addresses",
  mixins: [queries],
  data() {
    return {
      DIALOG: false,
      CITY_DIALOG: false,
      ACTIONS: ACTIONS,
      ACTION: ACTIONS.NO,
      FORM,
      content: [],
      cities: []
    };
  },
  watch: {
    DIALOG(value) {
      if (value === false) {
        this.FORM = { ...FORM };
        this.ACTION = ACTIONS.NO;
        this.$refs.form.resetValidation();
      }
    }
  },
  created() {
    this.startLoading();
    this.loadData();
  },
  methods: {
    loadData() {
      this.$axios
        .get("region/list", {
          params: {
            ...this.activeFilters,
            page: (Number(this.activeFilters.page) - 1).toString()
          }
        })
        .then(r => {
          this.stopLoading();
          this.content = r.data.data.content;
          this.pageable = {
            ...this.pageable,
            ...this.getPageable(r.data.data)
          };
        });
    },
    addAction() {
      this.DIALOG = true;
      this.ACTION = ACTIONS.ADD;
      this.FORM = { ...FORM };
    },
    editAction(data) {
      this.DIALOG = true;
      this.ACTION = ACTIONS.EDIT;
      this.FORM = { id: data.id, name: data.name, postCode: data.code };
    },
    deleteAction(data) {
      this.DIALOG = true;
      this.ACTION = ACTIONS.DELETE;
      this.FORM = { ...data };
    },
    store() {
      if (this.$refs.form.validate()) {
        this.startLoading();
        this.$axios.post("/region/add", this.FORM).then(async r => {
          this.DIALOG = false;
          await this.loadData();
          this.stopLoading();
        });
      }
    },
    update() {
      if (this.$refs.form.validate()) {
        this.startLoading();
        this.$axios.put(`/region/${this.FORM.id}`, this.FORM).then(async r => {
          this.DIALOG = false;
          await this.loadData();
          this.stopLoading();
        });
      }
    },
    destroy() {
      this.DIALOG = false;
    }
  }
};
</script>
