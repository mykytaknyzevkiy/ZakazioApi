<template>
  <v-container>
    <Spinner />
    <v-row>
      <v-col class="col-12 col-md-3">
        <v-card class="mb-3 d-sm-flex d-md-block" flat>
          <v-card-text>
            <div class="avatar">
              <v-img
                v-if="user.avatar !== null"
                class="avatar-img"
                :src="`${storageUrl}/${user.avatar}`"
                aspect-ratio="1"
              ></v-img>
              <span v-else>НК</span>
            </div>
          </v-card-text>
          <v-divider class="hidden-sm" />
          <v-list>
            <v-list-item>
              <v-chip-group>
                <v-chip outlined label>
                  <v-icon>{{ ROLES[user.role].icon }}</v-icon>
                  {{ ROLES[user.role].name }}
                </v-chip>
                <v-chip v-if="hasProp(user, 'rate')" outlined label
                  >Рейтинг: {{ user.rate }}</v-chip
                >
              </v-chip-group>
            </v-list-item>

            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-account</v-icon>
              </v-list-item-avatar>
              <v-list-item-title>
                {{
                  user.lastName + " " + user.firstName + " " + user.middleName
                }}</v-list-item-title
              >
            </v-list-item>
            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-email-outline</v-icon>
              </v-list-item-avatar>
              <v-list-item-title> {{ user.email }}</v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-phone-in-talk-outline</v-icon>
              </v-list-item-avatar>
              <v-list-item-title> {{ user.phoneNumber }}</v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-city</v-icon>
              </v-list-item-avatar>
              <v-list-item-title>
                {{
                  !user.city ? "нет города" : user.city.name
                }}</v-list-item-title
              >
            </v-list-item>
          </v-list>
          <v-divider />
          <v-card-text v-if="hasProp(order, 'count')">
            Открытые заказы - {{ order.count.open }} <br />
            Закрытые заказы - {{ order.count.close }}<br />
            Всего заказы - {{ order.count.open + order.count.close }}<br />
          </v-card-text>
        </v-card>
      </v-col>
      <v-col class="col-12 col-md-9">
        <v-card flat class="mb-4">
          <v-row class="py-4">
            <v-col
              class="col-4 d-flex flex-column align-center justify-center "
              :class="{
                'green--text': user.phoneActive,
                'red--text': !user.phoneActive
              }"
            >
              <div
                class="profile-item"
                :class="{ 'profile-item_red': !user.phoneActive }"
              >
                <v-icon class="mb-1" :color="user.phoneActive ? 'green' : 'red'"
                  >mdi-phone</v-icon
                >
                <span class="font-weight-light">Телефон</span>
              </div>
            </v-col>
            <v-col
              class="col-4 d-flex flex-column align-center justify-center"
              :class="{
                'green--text': user.emailActive,
                'red--text': !user.emailActive
              }"
            >
              <div
                class="profile-item"
                :class="{ 'profile-item_red': !user.emailActive }"
              >
                <v-icon class="mb-1" :color="user.emailActive ? 'green' : 'red'"
                  >mdi-email-outline</v-icon
                >
                <span class="font-weight-light">Email</span>
              </div>
            </v-col>
            <v-col
              class="col-4 d-flex flex-column align-center justify-center"
              :class="{
                'green--text': user.passportActive,
                'red--text': !user.passportActive
              }"
            >
              <div
                class="profile-item"
                :class="{ 'profile-item_red': !user.passportActive }"
              >
                <v-icon
                  class="mb-1"
                  :color="user.passportActive ? 'green' : 'red'"
                  >mdi-passport</v-icon
                >
                <div class="font-weight-light">Паспорт</div>
              </div>
            </v-col>
          </v-row>
        </v-card>
        <profile-passport :passport="passport" class="mb-4" />
        <profile-portfolio
          v-if="[ROLES.EXECUTOR.value].includes(user.role)"
          :id="$route.params.id"
          mode="view"
        />
        <profile-orders />
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import helpers from "@/mixins/helpers";
import { hasProp } from "@/helpers/helpers";
import ROLES from "@/constants/roles";
import ProfilePortfolio from "@/components/Profile/ProfilePortfolio";
import ProfilePassport from "@/components/Profile/ProfilePassport";
import ProfileOrders from "@/components/Profile/ProfileOrders";

// import user from "@/store/user";
/* const FORM = {
  email: "",
  password: "",
  firstName: "",
  lastName: "",
  middleName: "",
  user: true,
  partner: false,
  executor: false,
  agent: false,
  admin: false,
  superAdmin: true,
  editor: false
}; */
export default {
  name: "User",
  components: { ProfileOrders, ProfilePassport, ProfilePortfolio },
  mixins: [helpers],
  data() {
    return {
      user: {
        avatar: "",
        city: null,
        email: "",
        emailActive: false,
        firstName: "",
        id: null,
        lastName: "",
        masterID: null,
        middleName: "",
        passport: null,
        passportActive: false,
        phoneActive: false,
        phoneNumber: "",
        rate: 0,
        role: "CLIENT"
      },
      passport: {},
      order: {
        count: { open: 0, close: 0, max: 0 },
        enable: false
      },
      LOADING: false,
      FORM: {},
      ROLES
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    hasProp,
    resetForm() {
      this.LOADING = false;
      this.DIALOG = false;
    },
    loadData() {
      this.startLoading();
      const userId = this.$route.params.id;
      this.$axios.get(`user/${userId}`).then(response => {
        const {
          avatar,
          passportActive,
          phoneActive,
          id,
          emailActive,
          lastName,
          middleName,
          firstName,
          phoneNumber,
          email,
          role,
          rate
        } = response.data.data;
        this.user = {
          ...this.user,
          avatar,
          passportActive,
          phoneActive,
          id,
          emailActive,
          lastName,
          middleName,
          firstName,
          phoneNumber,
          email,
          role,
          rate
        };
        if (hasProp(response.data.data, "order")) {
          this.order = {
            count: { ...response.data.data.order.count },
            enable: response.data.data.order.enable
          };
        }
        if (response.data.data.passport !== null) {
          this.passport = {
            ...response.data.data.passport
          };
        }
        this.stopLoading();
      });
      /* this.$axios
        .get(`users/${userId}`)
        .then(response => {
          this.user = { ...this.user, ...response.data.data };
          this.stopLoading();
        })
        .catch(error => {
          const status = error.response.status;
          if (status === 404) {
            this.$router.push({ name: "NotFound" });
            this.stopLoading();
          }
        }); */
    },
    editAction() {
      this.FORM = { ...this.user };
      this.DIALOG = true;
    },
    async saveData() {
      this.LOADING = true;
      await this.$axios.put(`user/update/${this.user.id}`, this.FORM);
      await this.loadData();
      this.resetForm();
    }
  }
};
</script>

<style lang="scss" scoped>
.profile-item {
  background-color: lighten(#4caf50, 45%);
  border-radius: 50%;
  height: 100px;
  width: 100px;
  display: flex;
  flex-direction: column;
  padding: 10px;
  align-items: center;
  justify-content: center;
  &_red {
    background-color: lighten(#f44336, 35%);
  }
}
.avatar {
  width: 100%;
  background-color: #f8f8f8;
  position: relative;
  padding-bottom: 100%;
  border-radius: 4px;
  border: 1px dashed darken(#f8f8f8, 20%);
  span {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
  }
}
.avatar-btns {
  position: absolute;
  right: -10px;
  top: -10px;
}
.avatar-btn:first-child {
  margin-right: 5px;
}
.avatar-progress {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
}
.avatar-img {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.avatar-select {
  display: none;
}
</style>
