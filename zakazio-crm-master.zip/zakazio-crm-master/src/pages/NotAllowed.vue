<template>
  <v-container class="fill-height d-flex align-center justify-center">
    <span class="grey--text font-weight-light"
      >У вас нет доступак к этой странице!</span
    >
  </v-container>
</template>

<script>
export default {
  name: "NotAllowed"
};
</script>

<style scoped></style>
