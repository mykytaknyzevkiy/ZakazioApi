<template>
  <v-card class="mx-auto" flat>
    <v-card-title class="d-flex">
      <v-avatar color="blue-grey lighten-2" size="42" class="mr-3">
        <span class="white--text">{{
          `${executor.firstName[0]}${executor.lastName[0]}`
        }}</span>
      </v-avatar>
      <span>{{ `${executor.firstName} ${executor.lastName}` }}</span>
      <v-spacer />

      <v-btn
        v-if="cancelExecutorEnable"
        small
        depressed
        icon
        color="red"
        class="ml-3"
        ><v-icon @click="$emit('cancelExecutor')">mdi-close</v-icon></v-btn
      >
    </v-card-title>
    <v-divider />
    <v-row class="pt-3 pb-0 px-3 justify-space-around">
      <v-col class=" d-flex align-center">
        <v-icon color="indigo" class="mr-3"> mdi-email </v-icon>
        <span>{{ executor.email || "нет доступа" }}</span>
      </v-col>
      <v-divider vertical />
      <v-col class=" d-flex align-center">
        <v-icon color="indigo" class="mr-3">
          mdi-phone
        </v-icon>
        <span>{{ executor.phoneNumber || "нет доступа" }}</span>
      </v-col>
    </v-row>
    <v-card-actions> </v-card-actions>
  </v-card>
</template>

<script>
import { ORDER_STATUSES } from "@/constants/orderStatuses";

export default {
  name: "OrderExecutorCard",
  props: {
    cancelExecutorEnable: {
      type: Boolean,
      default: false
    },
    executor: {
      type: Object,
      default: () => {}
    },
    status: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      STATUSES: { ...ORDER_STATUSES }
    };
  }
};
</script>

<style scoped></style>
