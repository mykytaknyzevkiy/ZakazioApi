<template>
  <v-container>
    <spinner />

    <v-row class="px-0">
      <v-col class="col-12 col-md-4">
        <v-text-field
          hide-details="auto"
          outlined
          placeholder="Поиск"
          label="Поиск"
          clearable
          :value="activeFilters.search"
          @click:clear="filterResults('search', '')"
          @keydown.enter="filterResults('search', $event.target.value)"
        />
      </v-col>
    </v-row>

    <v-card class="mb-5" flat>
      <v-card-title>
        <span>Назначить исполнителя</span>
        <span class="ml-1 mr-auto font-weight-light body-1" />
      </v-card-title>
      <v-divider />
      <template v-for="(user, key) in users">
        <v-row :key="`user-${user.id}`" class="px-3">
          <v-col>
            <div class="caption grey--text">
              id
            </div>
            <div>
              {{ key + 1 }}
            </div>
          </v-col>
          <v-col>
            <div class="caption grey--text">
              Имя
            </div>
            <div>{{ user.firstName }} {{ user.lastName }}</div>
          </v-col>
          <v-col>
            <div class="caption grey--text">
              Email
            </div>
            <div>{{ user.email }}</div>
          </v-col>
          <v-col>
            <div class="caption grey--text">
              Телефон
            </div>
            <div>{{ user.phoneNumber }}</div>
          </v-col>
          <v-col>
            <v-btn
              :disabled="user.order.enable === false"
              small
              color="primary"
              @click="setExecutor(user.id)"
              >Назначить исполнителем</v-btn
            >
          </v-col>
        </v-row>
        <v-divider v-if="key + 1 < users.length" :key="`divider-${user.id}`" />
      </template>
      <template v-if="users.length === 0">
        <no-content />
      </template>
    </v-card>
    <div class="text-center">
      <v-pagination
        :length="pageable['totalPages']"
        :value="pageable['pageNumber']"
        @input="filterResults('page', $event)"
      />
    </div>
  </v-container>
</template>

<script>
import NoContent from "@/components/NoContent";
export default {
  name: "OrderSetExecutor",
  components: { NoContent },
  data() {
    return {
      pageable: {
        offset: 0,
        pageNumber: 0,
        pageSize: 0,
        paged: true,
        unpaged: false,
        totalElements: 0,
        totalPages: 0
      },
      activeFilters: {
        page: "1",
        search: ""
      },
      users: []
    };
  },
  async created() {
    this.activeFilters = { ...this.$route.query };
    await this.startLoading();
    await this.loadData();
  },
  methods: {
    async filterResults(prop, value) {
      const tValue = value.toString();
      if (prop !== "page") {
        this.activeFilters.page = "1";
      }
      this.activeFilters[prop] = tValue;
      if (this.$route.query[prop] !== tValue) {
        await this.$router.replace({
          query: {
            ...this.activeFilters
          }
        });
      }

      await this.startLoading();
      await this.loadData();
    },
    loadData() {
      this.$axios
        .get("/executor/list", {
          params: {
            ...this.activeFilters,
            page: (Number(this.activeFilters.page) - 1).toString()
          }
        })
        .then(response => {
          console.log(response);
          this.stopLoading();
          this.users = [...response.data.data.content];
          const {
            offset,
            pageNumber,
            pageSize,
            paged,
            unpaged
          } = response.data.data.pageable;
          this.pageable = {
            ...this.pageable,
            offset,
            pageNumber: pageNumber + 1,
            pageSize,
            paged,
            unpaged,
            totalElements: response.data.data.totalElements,
            totalPages: response.data.data.totalPages
          };
        })
        .catch(() => this.stopLoading());
    },
    setExecutor(executorId) {
      const orderId = this.$route.params.id;
      this.$axios
        .put(`/order/${orderId}/set/executor/${executorId}`)
        .then(async () => {
          this.$router.push(`/orders/${orderId}`);
        });
    }
  }
};
</script>

<style scoped></style>
