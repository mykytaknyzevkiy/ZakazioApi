<template>
  <v-col class="col-3">
    <v-card flat outlined :elevation="1">
      <v-card-text class="justify-center d-flex">
        <v-avatar color="red" size="62">
          <span class="white--text headline">{{
            `${executor.firstName[0]}${executor.lastName[0]}`
          }}</span>
        </v-avatar>
      </v-card-text>
      <v-divider />
      <v-row class="px-3">
        <v-col>
          <div class="caption grey--text">ФИО</div>
          <div>{{ `${executor.firstName} ${executor.lastName}` }}</div>
        </v-col>
      </v-row>
      <v-divider />
      <v-row class="px-3">
        <v-col>
          <div class="caption grey--text">Заказы</div>
          <div class="d-flex align-content-center">
            <v-icon size="16" class="mr-1 green--text text--darken-1"
              >mdi-check-decagram</v-icon
            >
            <span class="mr-3 green--text text--darken-1">{{
              successfulOrders
            }}</span>
            <v-icon size="16" class="mr-1 red--text">mdi-close-octagon</v-icon>
            <span class="red--text">{{ failedOrders }}</span>
          </div>
        </v-col>
      </v-row>
      <v-divider />
      <v-card-actions>
        <v-btn small depressed @click="$emit('setExecutor', executor.id)"
          >Назначить исполнителем</v-btn
        >
      </v-card-actions>
    </v-card>
  </v-col>
</template>

<script>
export default {
  name: "OrderSetExecutor",
  props: {
    executor: {
      type: Object,
      default: () => {}
    }
  },
  computed: {
    successfulOrders() {
      return this.executor.orders.reduce((acc, crnt) => {
        if (crnt.status === "executed" || crnt.status === "done") {
          return acc + 1;
        }
        return acc;
      }, 0);
    },
    failedOrders() {
      return this.executor.orders.reduce((acc, crnt) => {
        if (crnt.status === "cancel") {
          return acc + 1;
        }
        return acc;
      }, 0);
    }
  }
};
</script>

<style scoped></style>
