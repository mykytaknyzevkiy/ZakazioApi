<template>
  <v-container>
    <v-card class="mx-auto" max-width="600" flat>
      <v-form ref="form" @submit.prevent="store">
        <v-card-title>
          Заказ
        </v-card-title>
        <v-divider />
        <v-card-text class="pa-5">
          <v-text-field
            v-model="ORDER_FORM.title"
            class="mb-5"
            outlined
            label="Заголовок"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          />
          <v-textarea
            v-model="ORDER_FORM.content"
            class="mb-5"
            outlined
            label="Контент"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          />
          <v-text-field
            v-model.number="ORDER_FORM.price"
            class="mb-5"
            outlined
            label="Цена"
            hide-details="auto"
            placeholder=" "
            type="number"
            :rules="[v => !!v || '']"
          />
          <v-text-field
            v-model="ORDER_FORM.dateLine"
            class="mb-5"
            outlined
            label="Предварительный срок"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          />
          <v-autocomplete
            v-model="ORDER_FORM.cityID"
            prepend-icon="mdi-city"
            outlined
            hide-details="auto"
            label="Город"
            placeholder=" "
            :items="cities"
            item-text="name"
            item-value="id"
            class="mb-5"
          >
            <template v-slot:item="{ item }">
              <v-list-item-avatar
                color="indigo"
                class="headline font-weight-light white--text"
              >
                {{ item.name.charAt(0) }}
              </v-list-item-avatar>
              <v-list-item-content>
                <v-list-item-title v-text="item.name"></v-list-item-title>
                <v-list-item-subtitle
                  v-text="item.region.name"
                ></v-list-item-subtitle>
              </v-list-item-content>
            </template>
          </v-autocomplete>
          <v-text-field
            v-model="ORDER_FORM.client_first_name"
            class="mb-5"
            outlined
            label="Имя клиента"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          /><v-text-field
            v-model="ORDER_FORM.client_last_name"
            class="mb-5"
            outlined
            label="Фамилия клиента"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          /><v-text-field
            v-model="ORDER_FORM.client_middle_name"
            class="mb-5"
            outlined
            label="Отчество клиента"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          /><v-text-field
            v-model="ORDER_FORM.client_phone"
            class="mb-5"
            outlined
            label="Телфон клиента"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '']"
          /><v-text-field
            v-model="ORDER_FORM.client_email"
            outlined
            label="Email клиента"
            hide-details="auto"
            placeholder=" "
            :rules="[v => !!v || '', v => /.+@.+\..+/.test(v) || '']"
          />
        </v-card-text>
        <v-divider />
        <v-card-actions class="pa-5">
          <v-btn color="primary" type="submit">Сохранить</v-btn>
        </v-card-actions>
      </v-form>
    </v-card>
  </v-container>
</template>

<script>
const ORDER_FORM = {
  title: "",
  content: "",
  price: 0,
  dateLine: "",
  cityID: null,
  executorID: null,
  client_first_name: "",
  client_last_name: "",
  client_middle_name: "",
  client_phone: "",
  client_email: ""
};
export default {
  name: "OrdersAdd",
  data() {
    return {
      ORDER_FORM,
      cities: []
    };
  },
  created() {
    console.log(this.me);
    this.loadCities();
  },
  methods: {
    loadCities() {
      this.$axios.get(`region/city/search?query=&size=1000`).then(r => {
        this.cities = r.data.data.content;
      });
    },
    store() {
      if (this.$refs.form.validate()) {
        this.$axios.post("order/add", ORDER_FORM).then(() => {
          this.$router.push("/orders");
        });
      }
    }
  }
};
</script>
