<template>
  <v-container>
    <Spinner />
    <!--    <v-row align="center">
      <v-col>
        <v-btn-toggle dense class="mr-1">
          <v-btn value="day" @click="setDayRange('day')">
            День
          </v-btn>
          <v-btn value="week" @click="setDayRange('week')">
            Неделя
          </v-btn>
          <v-btn value="month" @click="setDayRange('month')">
            Месяц
          </v-btn>
          <v-menu :close-on-content-click="false" offset-y min-width="290px">
            <template v-slot:activator="{ on }">
              <v-btn v-on="on"
                ><v-icon left>
                  mdi-calendar
                </v-icon>
                {{ dateRangeText }}</v-btn
              >
            </template>
            <v-date-picker
              v-model="dateRange"
              range
              no-title
              locale="ru"
              @change="selectRange($event)"
            >
            </v-date-picker>
          </v-menu>
        </v-btn-toggle>
        <v-btn icon color="red" @click="clearRange">
          <v-icon>mdi-close-circle-outline</v-icon></v-btn
        >
      </v-col>
    </v-row>-->
    <v-card class="mb-5 mx-auto" max-width="850" flat>
      <v-card-title>
        <span>Заказы</span>
        <v-spacer />
        <v-btn
          to="/orders/add"
          depressed
          color="primary"
          :disabled="me.hasOwnProperty('order') && !me.order.enable"
          >Создать</v-btn
        >
      </v-card-title>
      <v-card-text v-if="me.hasOwnProperty('order') && !me.order.enable">
        Пока вы не подтвердите все данные, доступ к работе над заказами у вас
        закрыт.
        <br />
        <v-btn depressed class="mt-2" to="/profile">К профилю</v-btn>
      </v-card-text>

      <!--      <template v-for="order in orders">
        <router-link
          :key="`order-${order.id}`"
          class="list-link"
          :to="`/orders/${order.id}`"
        >
          <v-row class="px-3">
            <v-col>
              <div class="text-caption grey&#45;&#45;text">№ заказа</div>
              <div>{{ order.id }}</div>
            </v-col>
            <v-col>
              <div class="text-caption grey&#45;&#45;text">Название</div>
              <div>{{ order.title }}</div>
            </v-col>
            <v-col>
              <div class="text-caption grey&#45;&#45;text">Цена</div>
              <div>{{ order.price }}</div>
            </v-col>
            <v-col>
              <div class="text-caption grey&#45;&#45;text">Статус</div>
              <div class="d-flex align-center">
                <v-icon
                  size="16"
                  class="mr-2"
                  :class="STATUSES[order.status].color"
                  >mdi-circle</v-icon
                >
                {{ STATUSES[order.status].name }}
              </div>
            </v-col>
          </v-row>
        </router-link>
        <v-divider :key="`divider-${order.id}`" />
      </template>-->
      <template v-if="orders.length === 0">
        <v-divider />
        <no-content />
      </template>
    </v-card>
    <router-link
      v-for="order in orders"
      :key="order.id"
      :to="`/orders/${order.id}`"
      style="max-width: 850px"
      class="mb-5 v-card v-card--flat v-sheet theme--light mx-auto"
      outlined
    >
      <v-card-title class="px-5 justify-space-between">
        <h2
          class="font-weight-bold subtitle-1 mb-0"
          style="line-height: 19.2px"
        >
          {{ order.title }}
        </h2>
        <span
          style="color: rgba(0, 0, 0, 0.54); line-height: 16px"
          class="subtitle-2 font-weight-light"
          ><v-icon size="14">mdi-google-maps</v-icon>
          {{ order.city.name || "город не указан" }}</span
        >
      </v-card-title>
      <v-card-text class="px-5 py-0">{{ order.content }}</v-card-text>
      <v-card-actions class="px-5 justify-space-between">
        <v-chip-group>
          <v-chip label x-small :color="STATUSES[order.status].color">{{
            STATUSES[order.status].name
          }}</v-chip>
        </v-chip-group>
        <span class="text-caption">{{ order.price }} рублей</span>
      </v-card-actions>
      <v-divider />
      <v-card-text class="d-flex align-center">
        <v-avatar size="36px" color="red" class="mr-5">
          <img
            v-if="order.client.user.avatar !== null"
            alt="Avatar"
            :src="`${storageUrl}/${order.client.user.avatar}`"
          />
          <span v-else class="white--text">{{
            `${order.client.user.firstName[0]}${order.client.user.lastName[0]}`
          }}</span>
        </v-avatar>
        <div class="subtitle-1">
          {{ order.client.user.firstName + " " + order.client.user.lastName }}
        </div>
      </v-card-text>
    </router-link>
    <div class="text-center">
      <v-pagination
        :length="pageable['totalPages']"
        :value="pageable['pageNumber']"
        @input="filterResults('page', $event)"
      />
    </div>
  </v-container>
</template>
<script>
/* eslint-disable no-prototype-builtins */

import helpers from "@/mixins/helpers";
import filters from "@/mixins/filters";
import { ORDER_STATUSES } from "@/constants/orderStatuses";
import NoContent from "@/components/NoContent";
export default {
  name: "OrdersList",
  components: { NoContent },
  mixins: [helpers, filters],
  data() {
    return {
      orderActions: true,
      dateRange: [],
      STATUSES: { ...ORDER_STATUSES },
      orders: [],
      applications: [],
      meta: { maxPages: 0, pageNo: 0 },
      menu: false,
      pageable: {
        offset: 0,
        pageNumber: 0,
        pageSize: 0,
        paged: true,
        unpaged: false,
        totalElements: 0,
        totalPages: 0
      }
    };
  },

  async created() {
    await this.startLoading();
    await this.loadApplications();
    this.loadData();
  },
  methods: {
    clearHtml(content) {
      return content.replace(/(<([^>]+)>)/gi, "");
    },
    loadApplications() {
      /* this.$axios.get("partner/app/list").then(response => {
        this.applications = response.data.data.items;
        this.stopLoading();
      }); */
    },
    loadData() {
      this.$axios
        .get(`order/list`, {
          params: {
            ...this.activeFilters,
            page: (Number(this.activeFilters.page) - 1).toString()
          }
        })
        .then(response => {
          this.orders = response.data.data.content;
          this.orders = response.data.data.content;
          const {
            offset,
            pageNumber,
            pageSize,
            paged,
            unpaged
          } = response.data.data.pageable;
          this.pageable = {
            ...this.pageable,
            offset,
            pageNumber: pageNumber + 1,
            pageSize,
            paged,
            unpaged,
            totalElements: response.data.data.totalElements,
            totalPages: response.data.data.totalPages
          };
          this.stopLoading();
        });
    }
  }
};
</script>

<style scoped>
.list-link {
  text-decoration: none;
  color: #000;
}
</style>
