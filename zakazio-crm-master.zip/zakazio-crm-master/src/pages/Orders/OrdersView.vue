<template>
  <v-container>
    <Spinner />
    <v-row v-if="order.id !== 0">
      <v-col class="col-8">
        <v-card
          :class="{
            canceled: order.status === STATUSES.CANCEL.value,
            done: order.status === STATUSES.DONE.value
          }"
          class="mb-5"
          flat
        >
          <v-card-title>
            <div class="d-flex flex-column">
              <span>Заказ</span>
              <span class="text-caption">{{ order.id }} {{ order.title }}</span>
            </div>
            <v-spacer />
            <v-chip
              small
              outlined
              label
              :color="STATUSES[order.status].color"
              class="mr-3"
              >{{ STATUSES[order.status].name }}
            </v-chip>
            <div>
              <v-btn v-if="order.beExecutorEnable" small @click="beExecutor">
                <v-icon size="20">mdi-check</v-icon>
                <span>Стать исполнителем</span>
              </v-btn>
              <v-btn v-if="order.inWorkEnable" small @click="setExecuting">
                <v-icon size="20">mdi-cog-sync</v-icon>
                <span>Начать работу</span>
              </v-btn>
              <v-btn
                v-if="
                  order.executor !== null &&
                    order.cancelExecutorEnable &&
                    order.executor.id === userData.id
                "
                small
                class="mr-2"
                @click="cancelExecutor()"
                >Отказаться</v-btn
              >
              <!--              <v-btn v-if="order.doneEnable" small @click="completeOrder"
                >Завершить работу</v-btn
              >-->
            </div>
            <v-btn
              v-if="order.setExecutorEnable"
              small
              class="mr-2"
              :to="`/orders/${order.id}/set-executor`"
              >{{
                order.executor === null
                  ? "Назначить исполнителя"
                  : "Сменить исполнителя"
              }}</v-btn
            >
            <v-btn
              v-if="order.cancelEnable"
              small
              class="red--text"
              @click="cancelOrder()"
              ><v-icon size="20">mdi-cancel</v-icon><span>Отменить</span>
            </v-btn>
            <v-btn v-if="order.doneEnable" small @click="closeOrder()"
              ><v-icon size="20">mdi-notebook-check-outline</v-icon
              ><span>Завершить</span>
            </v-btn>
          </v-card-title>
          <v-divider />
          <!--<v-row class="px-3">
            <v-col>
              <div class="caption grey&#45;&#45;text">Категория</div>
              <div>{{ order.category.name }}</div>
            </v-col>
          </v-row>-->
          <v-divider />
          <v-row class="px-3">
            <v-col>
              <v-col class="flex-grow-1">
                <div class="caption grey&#45;&#45;text">Контент</div>
                <div v-html="order.content"></div>
              </v-col>
              <v-divider />
              <v-col class="flex-grow-1">
                <div class="caption grey&#45;&#45;text">Цена</div>
                <div>{{ order.price }}</div>
              </v-col>
            </v-col>
            <v-col class="d-flex justify-end">
              <v-btn
                v-if="order.editEnable"
                icon
                small
                depressed
                @click="editOrder"
              >
                <v-icon>mdi-file-edit-outline</v-icon>
              </v-btn>
            </v-col>
          </v-row>
          <v-divider />
          <v-row class="px-3">
            <v-col>
              <div class="caption grey--text">Дата создания</div>
              <div>{{ order.creationDate | moment("DD.MM.YYYY") }}</div>
            </v-col>
          </v-row>
        </v-card>
        <order-executor-card
          v-if="order.executor !== null"
          class="mb-3"
          :executor="order.executor"
          :status="order.status"
          :cancel-executor-enable="order.cancelExecutorEnable"
          @cancelExecutor="cancelExecutor()"
        />
        <!-- <order-comments
            :comments="comments.items"
            :max-pages="comments.maxPages"
            :page-no="comments.pageNo"
            @store="addComment($event)"
            @changePage="loadComments($event)"
          />-->
      </v-col>
      <v-col class="col-4">
        <v-card v-if="order.client !== null" flat>
          <v-card-title>Клиент</v-card-title>
          <v-divider />
          <v-card-text class="justify-center d-flex">
            <v-avatar color="red" size="62">
              <span class="white&#45;&#45;text headline">{{
                `${order.client.firstName[0]}${order.client.lastName[0]}`
              }}</span>
            </v-avatar>
          </v-card-text>
          <v-list two-line>
            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo">
                  mdi-account-circle-outline
                </v-icon>
              </v-list-item-icon>
              <v-list-item-content>
                <v-list-item-title
                  >{{ `${order.client.firstName} ${order.client.lastName}` }}
                </v-list-item-title>
                <v-list-item-subtitle>ФИО</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>

            <v-divider inset></v-divider>

            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo">
                  mdi-phone
                </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title
                  >{{ order.client.phoneNumber || "нет доступа" }}
                </v-list-item-title>
                <v-list-item-subtitle>телефон</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>

            <v-divider inset></v-divider>

            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo">
                  mdi-email
                </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title>{{
                  order.client.email || "нет доступа"
                }}</v-list-item-title>
                <v-list-item-subtitle>email</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>
          </v-list>
        </v-card>
      </v-col>
    </v-row>
    <v-dialog v-model="editModal" max-width="600">
      <v-card>
        <v-card-title>Изменить детали</v-card-title>
        <v-card-text>
          <wysiwyg v-model="ORDER_FORM.content" placeholder="Контент" />
          <v-text-field
            v-model.number="ORDER_FORM.totalPrice"
            type="number"
            label="Цена"
          ></v-text-field>
        </v-card-text>
        <v-divider />
        <v-card-actions>
          <v-btn small depressed @click="updateOrder">Сохранить</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!--<order-be-executor-dialog @addComment="addComment($event)" />
    <order-cancel-executor-dialog @addComment="addComment($event)" />
    <order-set-executing-dialog @addComment="addComment($event)" />
    <order-complete-order-dialog @addComment="addComment($event)" />
    <order-cancel-order-dialog @addComment="addComment($event)" />
    <order-close-order-dialog @addComment="addComment($event)" />-->
  </v-container>
</template>

<script>
import { mapGetters } from "vuex";
import { ORDER_STATUSES } from "@/constants/orderStatuses";
import ROLES from "@/constants/roles";
// import OrderSetExecutor from "@/pages/Orders/OrderSetExecutor";
import OrderExecutorCard from "@/pages/Orders/OrderExecutorCard";
// import OrderComments from "@/components/Order/OrderComments";
// import OrderCancelExecutorDialog from "@/components/Order/OrderCancelExecutorDialog";
// import OrderSetExecutingDialog from "@/components/Order/OrderSetExecutingDialog";
// import OrderCompleteOrderDialog from "@/components/Order/OrderСompleteOrderDialog";
// import OrderCancelOrderDialog from "@/components/Order/OrderCancelOrderDialog";
// import OrderBeExecutorDialog from "@/components/Order/OrderBeExecutorDialog";
// import NoContent from "@/components/NoContent";
// import OrderCloseOrderDialog from "@/components/Order/OrderCloseOrderDialog";

const ORDER_FORM = {
  content: "",
  totalPrice: 0
};

export default {
  name: "OrdersView",
  components: {
    // OrderCloseOrderDialog,
    // NoContent,
    // OrderBeExecutorDialog,
    // OrderCancelOrderDialog,
    // OrderCompleteOrderDialog,
    // OrderSetExecutingDialog,
    // OrderCancelExecutorDialog,
    // OrderComments,
    OrderExecutorCard
    // OrderSetExecutor
  },
  data() {
    return {
      ROLES: { ...ROLES },
      STATUSES: { ...ORDER_STATUSES },
      ORDER_FORM: { ...ORDER_FORM },

      executorModal: false,
      editModal: false,

      executors: [],
      order: {
        id: 0,
        status: ORDER_STATUSES.PROCESS.value,
        title: "",
        content: "",
        beExecutorEnable: false,
        inWorkEnable: false,
        cancelExecutorEnable: false,
        doneEnable: false,
        setExecutorEnable: false,
        cancelEnable: false,
        executor: null,
        creationDate: null,
        editEnable: false
      },
      comments: {
        items: [],
        maxPages: null,
        pageNo: null
      }
    };
  },
  computed: {
    ...mapGetters(["role", "userData"]),
    isOwner() {
      // eslint-disable-next-line no-prototype-builtins
      if (!this.order.hasOwnProperty("app")) return false;
      return this.userData.id === this.order.app.partner.id;
    },
    hasPermissions() {
      return (
        this.role === "superAdmin" ||
        this.role === "admin" ||
        this.role === "editor" ||
        this.isOwner
      );
    },
    displayStatus() {
      if (this.order.status === "process") return "В обработке";
      if (this.order.status === "executing") return "В работе";
      if (this.order.status === "executed") return "Завершено";
      if (this.order.status === "cancel") return "Отменено";
      return "";
    }
  },
  created() {
    this.startLoading();
    this.loadData();
  },
  methods: {
    // стать исполнителем
    beExecutor() {
      const orderId = this.$route.params.id;
      this.startLoading();
      this.$axios.put(`/order/${orderId}/be/executor`).then(() => {
        this.loadData();
      });
    },
    // начать работу
    setExecuting() {
      const orderId = this.$route.params.id;
      this.startLoading();
      this.$axios.put(`/order/${orderId}/set/status/work`).then(() => {
        this.loadData();
        this.$root.$emit("orderBeExecutorDialog");
      });
    },
    // отказаться
    cancelExecutor() {
      const orderId = this.$route.params.id;
      this.startLoading();
      this.$axios.put(`/order/${orderId}/cancel/executor`).then(() => {
        this.loadData();
        // this.$root.$emit("cancelExecutorDialog");
      });
    },
    // завершить работу
    /* completeOrder() {
      const orderId = this.$route.params.id;
      this.$axios
        .put(`/order/${orderId}/status/set/executed`)
        .then(async () => {
          await this.startLoading();
          this.$root.$emit("orderCompleteOrderDialog");
          await this.loadData();
        });
    }, */
    async addComment(data) {
      const orderId = this.$route.params.id;
      await this.$axios.post(`/order/${orderId}/comment/`, data);
      this.$root.$emit("commentWasAdded");
      // this.loadComments();
    },
    /* loadExecutors() {
      this.$axios.get("/executor/list").then(response => {
        this.executors = response.data.data.items;
        console.log(response);
      });
    }, */
    loadComments(page = 1) {
      const orderId = this.$route.params.id;
      this.$axios
        .get(`/order/${orderId}/comment/?page=${page}&size=5`)
        .then(response => (this.comments = { ...response.data.data }));
    },
    async loadData() {
      const orderId = this.$route.params.id;
      await this.$axios
        .get(`/order/${orderId}/info`)
        .then(response => {
          this.order = { ...this.order, ...response.data.data };
        })
        .catch(() => this.stopLoading());
      /* if (this.order.executor !== null) {
        await this.loadComments();
      } */

      this.stopLoading();
    },

    editOrder() {
      this.editModal = true;
      this.ORDER_FORM = {
        ...ORDER_FORM,
        content: this.order.content,
        totalPrice: this.order.totalPrice
      };
    },
    updateOrder() {
      const orderId = this.$route.params.id;
      this.$axios.put(`/order/${orderId}`, this.ORDER_FORM).then(async () => {
        await this.startLoading();
        await this.loadData();
        this.editModal = false;
      });
    },
    cancelOrder() {
      const orderId = this.$route.params.id;
      this.$axios.put(`/order/${orderId}/status/set/cancel`).then(async () => {
        await this.startLoading();
        this.$root.$emit("orderCancelOrderDialog");
        await this.loadData();
      });
    },
    closeOrder() {
      const orderId = this.$route.params.id;
      this.$axios.put(`/order/${orderId}/status/set/done`).then(async () => {
        await this.startLoading();
        this.$root.$emit("orderCloseOrderDialog");
        await this.loadData();
      });
    },

    setExecutor(executorId) {
      const orderId = this.$route.params.id;
      this.$axios
        .put(`/order/${orderId}/set/executor`, { id: executorId })
        .then(async () => {
          await this.startLoading();
          await this.loadData();
          this.executorModal = false;
        });
    }
  }
};
</script>

<style scoped>
.canceled {
  border-top: 3px solid red;
}
.done {
  border-top: 3px solid green;
}
</style>
