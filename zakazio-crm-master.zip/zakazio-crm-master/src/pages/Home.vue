<template>
  <v-container class="fill-height d-flex">
    <v-card
      dark
      style="width: 100%; max-width: 320px"
      class="mt-0 mb-auto"
      outlined
    >
      <v-card-title style="font-size: 15px">
        Ваш баланс
      </v-card-title>
      <v-divider />
      <v-card-text class="d-flex align-center">
        <v-icon class="mr-3">mdi-credit-card</v-icon>
        <span style="font-size: 18px; color: white"
          >{{ balance }} ₽</span
        ></v-card-text
      >
    </v-card>
    <!--<span class="grey&#45;&#45;text font-weight-light">Привет из CRM!</span>-->
  </v-container>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      balance: 0
    };
  }
};
</script>
