<template>
  <v-container>
    <Spinner />
    <v-card class="mb-5" flat>
      <v-card-title>
        <span>Приложения – {{ apps.length }}</span>
        <v-spacer />
        <v-btn depressed small :to="{ name: 'ApplicationsCreate' }">
          Создать
        </v-btn>
      </v-card-title>
      <v-divider />
      <template v-for="(app, key) in apps">
        <router-link
          :key="`app-${app.id}`"
          class="data-table-row"
          :to="{ name: 'ApplicationsView', params: { id: app.id } }"
        >
          <v-row class="px-3">
            <v-col>
              <div class="caption grey--text">
                id
              </div>
              <div>
                {{ key + 1 }}
              </div>
            </v-col>
            <v-col>
              <div class="caption grey--text">
                Имя
              </div>
              <div>
                {{ app.name }}
              </div>
            </v-col>
            <v-col>
              <div class="caption grey--text">
                APP_KEY
              </div>
              <div>
                {{ app.key }}
              </div>
            </v-col>
          </v-row>
        </router-link>

        <v-divider v-if="key + 1 < apps.length" :key="`divider-${app.id}`" />
      </template>
      <template v-if="apps.length === 0">
        <no-content />
      </template>
    </v-card>
  </v-container>
</template>

<script>
import helpers from "@/mixins/helpers";

import filters from "@/mixins/filters";
import ACTIONS from "@/constants/acitions";
import NoContent from "@/components/NoContent";

export default {
  name: "ApplicationsList",
  components: { NoContent },
  mixins: [helpers, filters],
  data() {
    return {
      ACTIONS,
      meta: {
        maxPages: 0,
        pageNo: 1
      },
      activeFilters: {
        page: "1",
        search: ""
      },
      pageable: {
        offset: 0,
        pageNumber: 0,
        pageSize: 0,
        paged: true,
        unpaged: false,
        totalElements: 0,
        totalPages: 0
      },
      apps: []
    };
  },
  created() {
    // this.startLoading();
    this.loadData();
  },
  methods: {
    loadData() {
      this.$axios
        .get("app/list", {
          params: {
            ...this.activeFilters,
            page: (Number(this.activeFilters.page) - 1).toString()
          }
        })
        .then(response => {
          this.stopLoading();
          this.apps = [...response.data.data.content];
          const {
            offset,
            pageNumber,
            pageSize,
            paged,
            unpaged
          } = response.data.data.pageable;
          this.pageable = {
            ...this.pageable,
            offset,
            pageNumber: pageNumber + 1,
            pageSize,
            paged,
            unpaged,
            totalElements: response.data.data.totalElements,
            totalPages: response.data.data.totalPages
          };
        });
    }
    /* createAction() {
      this.ACTION = this.ACTIONS.CREATE_ACTION;
      this.DIALOG = true;
    },
    editAction(app) {
      this.ACTION = this.ACTIONS.EDIT_ACTION;
      this.FORM = { ...app };
      this.DIALOG = true;
    },
    deleteAction(app) {
      this.ACTION = this.ACTIONS.DELETE_ACTION;
      this.FORM = { ...app };
      this.DIALOG = true;
    }, */

    /* update() {
      this.$axios
        .put(`partner/app/${this.FORM.id}`, this.FORM)
        .then(async () => {
          await this.startLoading();
          await this.loadData();
          this.DIALOG = false;
        });
    },
    destroy() {
      this.$axios.delete(`partner/app/${this.FORM.id}`).then(async () => {
        await this.startLoading();
        await this.loadData();
        this.DIALOG = false;
      });
    } */
  }
};
</script>
<style>
.data-table-row {
  text-decoration: none;
}
</style>
