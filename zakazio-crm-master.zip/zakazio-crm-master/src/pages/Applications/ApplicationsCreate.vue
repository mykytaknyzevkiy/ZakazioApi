<template>
  <v-container>
    <v-card class="mb-5" flat>
      <v-card-title>Создание приложения</v-card-title>
      <v-divider />
      <v-card-text class="pt-3">
        <v-text-field v-model="FORM.name" label="Название" />
        <!--        <v-text-field v-model="FORM.secret" label="Секретный код" />-->
      </v-card-text>
      <v-divider />
      <v-card-actions>
        <v-spacer />
        <v-btn depressed small @click="store()">
          Далее
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-container>
</template>

<script>
const FORM = {
  name: "",
  key: ""
};
export default {
  name: "ApplicationsCreate",
  data() {
    return {
      FORM: { ...FORM }
    };
  },
  methods: {
    async store() {
      await this.startLoading();
      this.$axios.post("app/add", this.FORM).then(() => {
        this.$router.push({
          name: "Applications"
        });
      });
    }
  }
};
</script>
