<template>
  <v-container>
    <v-card class="mb-5" flat>
      <v-card-title>О приложении</v-card-title>
      <v-divider />

      <v-tabs v-model="TAB">
        <v-tab :key="TABS.GENERAL">
          Общие настройки
        </v-tab>
        <v-tab :key="TABS.NOTIFIER">
          Уведомитель
        </v-tab>
        <v-tab :key="TABS.SERVICES">
          Сервисы
        </v-tab>
      </v-tabs>
      <v-tabs-items v-model="TAB">
        <v-tab-item :key="TABS.GENERAL">
          <v-card flat>
            <v-row class="px-3">
              <v-col class="col-2 grey--text d-flex align-center">
                Имя приложения
              </v-col>
              <v-col class="col-10 d-flex align-center">
                <template v-if="ACTION === ACTIONS.NO_ACTION">
                  <span class="mr-3">{{ APPLICATION.name }}</span>
                  <v-btn icon small @click="editAction()">
                    <v-icon>mdi-playlist-edit</v-icon>
                  </v-btn>
                </template>
                <template v-else>
                  <v-text-field
                    v-model="FORM_NAME.name"
                    dense
                    class="flex-shrink-1 flex-grow-0"
                    @keyup.enter="update()"
                  />
                  <v-btn icon small @click="update()">
                    <v-icon>mdi-check</v-icon>
                  </v-btn>
                </template>
              </v-col>
            </v-row>

            <v-row class="px-3">
              <v-col class="col-2 grey--text d-flex align-center">
                <span>APP_KEY</span>
                <v-tooltip bottom>
                  <template v-slot:activator="{ on, attrs }">
                    <v-icon
                      size="16"
                      color="grey"
                      dark
                      v-bind="attrs"
                      v-on="on"
                    >
                      mdi-help-circle-outline
                    </v-icon>
                  </template>
                  <span
                    >Этот ключ используется для идентификации приложения при
                    использовании нашего SDK</span
                  >
                </v-tooltip>
              </v-col>
              <v-col class="col-10">
                {{ APPLICATION.key }}
              </v-col>
            </v-row>
          </v-card>
        </v-tab-item>
        <v-tab-item :key="TABS.NOTIFIER">
          <v-card flat>
            <v-card-text>
              <v-card outlined>
                <v-card-text>
                  <div class="mb-3">
                    Вам необходимо добавить в систему адрес вашего API, по
                    которому наша система будет связываться с ним с помощью
                    POST-запроса где будет сообщаться о новых заказах,
                    отредактированных заказах, отмененных заказах, и любой
                    другой информации, связанной с вашими заказами и вашем
                    приложением. Тело запроса будет следующего вида:
                  </div>
                  <prism language="json" :code="code" />
                  <!--                  <div v-if="APPLICATION.notifyCurl !== null" class="mb-3">
                    Текущий адрес: <code>{{ APPLICATION.notifyCurl }}</code>
                  </div>-->
                  <div class="d-flex">
                    <template v-if="ACTION === ACTIONS.NO_ACTION">
                      <template v-if="APPLICATION.notifyCurl === null">
                        <v-btn depressed small @click="editNotifyAction()">
                          Создать
                        </v-btn>
                      </template>
                      <template v-else>
                        <v-btn depressed small @click="editNotifyAction()">
                          Изменить
                        </v-btn>
                      </template>
                    </template>
                    <template v-else>
                      <v-text-field
                        v-model="FORM_NOTIFY.notifyCurl"
                        dense
                        class=""
                        @keyup.enter="updateNotify()"
                      />
                      <v-btn icon small @click="updateNotify()">
                        <v-icon>mdi-check</v-icon>
                      </v-btn>
                    </template>
                  </div>
                </v-card-text>
              </v-card>
            </v-card-text>
          </v-card>
        </v-tab-item>
        <v-tab-item :key="TAB.SERVICES">
          <v-row class="px-3">
            <v-col class="col-4 d-flex">
              <v-card
                elevation="1"
                class="flex-grow-1 d-flex flex-column"
                outlined
              >
                <v-card-title>Заказы</v-card-title>
                <v-divider />
                <v-card-text>
                  Вы сможете через наш SDK создавать заказы через ваше
                  приложение и модерировать их через CRM
                </v-card-text>
                <v-card-actions class="mb-0 mt-auto">
                  <v-btn
                    :to="`/apps/view/${APPLICATION.publicKey}/docs/orders`"
                    depressed
                    small
                  >
                    К документации
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-col>
            <v-col class="col-4 d-flex">
              <v-card
                elevation="1"
                class="flex-grow-1 d-flex flex-column"
                outlined
              >
                <v-card-title>Клиенты</v-card-title>
                <v-divider />
                <v-card-text>
                  Вы сможете рабоать с даными своих клиентов
                </v-card-text>
                <v-card-actions class="mb-0 mt-auto">
                  <v-btn
                    :to="`/apps/view/${APPLICATION.publicKey}/docs/clients`"
                    depressed
                    small
                  >
                    К документации
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-col>
            <v-col class="col-4 d-flex">
              <v-card
                elevation="1"
                class="flex-grow-1 d-flex flex-column"
                outlined
              >
                <v-card-title>Категории</v-card-title>
                <v-divider />
                <v-card-text>
                  Здесь вы можете получить информацию о категориях.
                </v-card-text>
                <v-card-actions class="mb-0 mt-auto">
                  <v-btn
                    :to="`/apps/view/${APPLICATION.key}/docs/categories`"
                    depressed
                    small
                  >
                    К документации
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-col>
            <v-col class="col-4 d-flex">
              <v-card
                elevation="1"
                class="flex-grow-1 d-flex flex-column"
                outlined
              >
                <v-card-title>Регистрация исполнителя</v-card-title>
                <v-divider />
                <v-card-text>
                  Здесь вы можете получить информацию о регистрации исполнителя
                  от имени партнера.
                </v-card-text>
                <v-card-actions class="mb-0 mt-auto">
                  <v-btn
                    :to="`/apps/view/${APPLICATION.key}/docs/executors`"
                    depressed
                    small
                  >
                    К документации
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-col>
          </v-row>
        </v-tab-item>
      </v-tabs-items>
    </v-card>
  </v-container>
</template>

<script>
import Prism from "vue-prism-component";
import "prismjs/components/prism-json";
const TABS = {
  GENERAL: "TAB_GENERAL",
  NOTIFIER: "TAB_NOTIFIER",
  SERVICES: "TAB_SERVICES"
};
const APPLICATION = {
  id: null,
  name: "",
  partner: {},
  privateKey: "",
  key: ""
};
const ACTIONS = {
  NO_ACTION: "NO_ACTION",
  EDIT_ACTION: "EDIT_ACTION",
  CREATE_ACTION: "CREATE_ACTION"
};
const FORM_NAME = {
  id: null,
  name: "",
  key: ""
};
const FORM_NOTIFY = {
  id: null,
  notifyCurl: ""
};
export default {
  name: "ApplicationsView",
  components: {
    Prism
  },
  data() {
    return {
      code: `{
  title: '',
  orderID: null,
  message: ''
}`,
      FORM_NAME: { ...FORM_NAME },
      FORM_NOTIFY: { ...FORM_NOTIFY },
      TAB: TABS.GENERAL,
      TABS: { ...TABS },
      ACTIONS: { ...ACTIONS },
      ACTION: ACTIONS.NO_ACTION,
      id: this.$route.params.id,
      APPLICATION: { ...APPLICATION }
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    editAction() {
      this.ACTION = ACTIONS.EDIT_ACTION;
      this.FORM_NAME = {
        id: this.APPLICATION.id,
        name: this.APPLICATION.name,
        key: ""
      };
    },
    editNotifyAction() {
      this.ACTION = ACTIONS.EDIT_ACTION;
      this.FORM_NOTIFY = {
        id: this.APPLICATION.id,
        title: this.APPLICATION.name,
        notifyCurl: this.APPLICATION.notifyCurl ?? ""
      };
    },
    update() {
      this.$axios
        .put(`app/${this.FORM_NAME.id}/update`, {
          name: this.FORM_NAME.name,
          key: this.FORM_NAME.key
        })
        .then(async () => {
          this.ACTION = ACTIONS.NO_ACTION;
          this.FORM_NAME = { ...FORM_NAME };
          await this.startLoading();
          await this.loadData();
        });
    },
    updateNotify() {
      this.$axios
        .put(`partner/app/${this.FORM_NOTIFY.id}`, this.FORM_NOTIFY)
        .then(async () => {
          this.ACTION = ACTIONS.NO_ACTION;
          this.FORM_NOTIFY = { ...FORM_NOTIFY };
          await this.startLoading();
          await this.loadData();
        });
    },
    loadData() {
      this.$axios.get(`/app/${this.id}`).then(res => {
        console.log(res.data.data);
        this.APPLICATION = { ...res.data.data };
      });
    }
  }
};
</script>

<style scoped></style>
