<template>
  <v-container>
    <Spinner />
    <v-row>
      <v-col class="col-12 col-md-3">
        <v-card class="mb-3 d-sm-flex d-md-block" flat>
          <v-card-text>
            <input
              ref="selectAvatar"
              accept="image/x-png,image/jpeg"
              type="file"
              class="avatar-select"
              @change="prepareAvatar($event)"
            />
            <div class="avatar">
              <v-img
                v-if="userData.avatar !== null"
                class="avatar-img"
                :src="`${storageUrl}/${userData.avatar}`"
                aspect-ratio="1"
              ></v-img>
              <span v-else>{{
                userData.firstName[0] + userData.lastName[0]
              }}</span>
              <v-progress-circular
                v-if="loadingAvatar"
                :width="3"
                color="red"
                indeterminate
                class="avatar-progress"
              ></v-progress-circular>
              <div class="avatar-btns">
                <v-btn
                  class="primary avatar-btn"
                  color="white"
                  icon
                  @click="$refs.selectAvatar.click()"
                  ><v-icon size="23">mdi-camera-plus-outline</v-icon></v-btn
                >
                <v-btn
                  v-if="userData.avatar !== null"
                  class="red avatar-btn"
                  color="white"
                  icon
                  @click.prevent="removeAvatar"
                  ><v-icon size="23">mdi-close</v-icon></v-btn
                >
              </div>
            </div>
          </v-card-text>
          <v-divider class="hidden-sm" />
          <v-list>
            <v-list-item class="d-flex justify-end">
              <v-btn
                class="primary"
                color="white"
                icon
                @click="editProfileData"
              >
                <v-icon>mdi-playlist-edit</v-icon>
              </v-btn>
            </v-list-item>

            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-account</v-icon>
              </v-list-item-avatar>
              <v-list-item-title>
                {{
                  userData.lastName +
                    " " +
                    userData.firstName +
                    " " +
                    userData.middleName
                }}</v-list-item-title
              >
            </v-list-item>
            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-email-outline</v-icon>
              </v-list-item-avatar>
              <v-list-item-title> {{ userData.email }}</v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-phone-in-talk-outline</v-icon>
              </v-list-item-avatar>
              <v-list-item-title> {{ userData.phoneNumber }}</v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-avatar>
                <v-icon>mdi-city</v-icon>
              </v-list-item-avatar>
              <v-list-item-title>
                {{
                  !userData.city ? "нет города" : userData.city.name
                }}</v-list-item-title
              >
            </v-list-item>
          </v-list>
        </v-card>
        <v-card
          v-if="userData.hasOwnProperty('order') && userData.order !== null"
          flat
          ><v-card-text class="d-flex justify-center align-center flex-column">
            <span class="text-h2">{{ userData.rate }}</span>
            <v-rating
              half-increment
              size="34"
              :value="userData.rate"
            ></v-rating>
          </v-card-text>
          <v-divider />
          <v-card-text>
            <div class="text-h6">Заказы</div>
            <v-chip label outlined color="grey" class="text-subtitle-1 ma-1"
              ><v-icon size="17">mdi-timer-sand</v-icon> В работе -
              {{ userData.order.count.open }}</v-chip
            >
            <v-chip label outlined color="green" class="text-subtitle-1 ma-1"
              ><v-icon size="17">mdi-check-circle-outline</v-icon> Закончено -
              {{ userData.order.count.close }}</v-chip
            >
            <v-chip label outlined class="text-subtitle-1 ma-1"
              ><v-icon size="17">mdi-chart-box-outline</v-icon> Всего -
              {{ userData.order.count.max }}</v-chip
            >
          </v-card-text>
        </v-card>
      </v-col>
      <v-col class="col-12 col-md-9">
        <v-card flat class="mb-4">
          <v-row class="py-4">
            <v-col
              class="col-4 d-flex flex-column align-center justify-center "
              :class="{
                'green--text': userData.phoneActive,
                'red--text': !userData.phoneActive
              }"
            >
              <div
                class="profile-item"
                :class="{ 'profile-item_red': !userData.phoneActive }"
              >
                <v-icon
                  class="mb-1"
                  :color="userData.phoneActive ? 'green' : 'red'"
                  >mdi-phone</v-icon
                >
                <span class="font-weight-light">Телефон</span>
              </div>
              <v-btn
                v-if="!userData.phoneActive"
                to="/verify/phone"
                depressed
                x-small
                ><v-icon size="12" color="red" class="mr-1">mdi-alert</v-icon>
                Подтвердить</v-btn
              >
            </v-col>
            <v-col
              class="col-4 d-flex flex-column align-center justify-center"
              :class="{
                'green--text': userData.emailActive,
                'red--text': !userData.emailActive
              }"
            >
              <div
                class="profile-item"
                :class="{ 'profile-item_red': !userData.emailActive }"
              >
                <v-icon
                  class="mb-1"
                  :color="userData.emailActive ? 'green' : 'red'"
                  >mdi-email-outline</v-icon
                >
                <span class="font-weight-light">Email</span>
              </div>
              <v-btn
                v-if="!userData.emailActive"
                to="/verify/email"
                depressed
                x-small
                ><v-icon size="12" color="red" class="mr-1">mdi-alert</v-icon>
                Подтвердить</v-btn
              >
            </v-col>
            <v-col
              class="col-4 d-flex flex-column align-center justify-center"
              :class="{
                'green--text': userData.passportActive,
                'red--text': !userData.passportActive
              }"
            >
              <div
                class="profile-item"
                :class="{ 'profile-item_red': !userData.passportActive }"
              >
                <v-icon
                  class="mb-1"
                  :color="userData.passportActive ? 'green' : 'red'"
                  >mdi-passport</v-icon
                >
                <div class="font-weight-light">Паспорт</div>
              </div>
              <v-btn
                v-if="!userData.passportActive"
                to="/verify/passport"
                depressed
                x-small
                ><v-icon size="12" color="red" class="mr-1"
                  >mdi-cloud-upload</v-icon
                >
                Загрузить</v-btn
              >
            </v-col>
          </v-row>
        </v-card>
        <profile-portfolio />
        <profile-orders />
      </v-col>
    </v-row>
    <v-dialog v-model="userDataDialog" max-width="700">
      <v-card>
        <v-form ref="userDataForm">
          <v-card-title>Личные данные</v-card-title>
          <v-divider />
          <v-card-text class="pa-5">
            <v-text-field
              v-model="USER_DATA_FORM.firstName"
              dense
              class="mb-5"
              outlined
              hide-details="auto"
              label="Имя"
              placeholder=" "
              :rules="[v => !!v || '']"
            />
            <v-text-field
              v-model="USER_DATA_FORM.lastName"
              dense
              class="mb-5"
              outlined
              hide-details="auto"
              label="Фамилия"
              placeholder=" "
              :rules="[v => !!v || '']"
            />
            <v-text-field
              v-model="USER_DATA_FORM.middleName"
              dense
              class="mb-5"
              outlined
              hide-details="auto"
              label="Отчество"
              placeholder=" "
              :rules="[v => !!v || '']"
            />
            <v-text-field
              v-model="USER_DATA_FORM.email"
              dense
              class="mb-5"
              outlined
              hide-details="auto"
              label="Email"
              placeholder=" "
              :rules="[v => !!v || '']"
            />
            <v-text-field
              v-model="USER_DATA_FORM.phoneNumber"
              dense
              outlined
              hide-details="auto"
              label="Телефон"
              class="mb-5"
              placeholder=" "
              :rules="[v => !!v || '']"
            />
            <v-autocomplete
              v-model="USER_DATA_FORM.cityID"
              prepend-icon="mdi-city"
              dense
              outlined
              hide-details="auto"
              label="Город"
              placeholder=" "
              :items="cities"
              item-text="name"
              item-value="id"
            >
              <template v-slot:item="{ item }">
                <v-list-item-avatar
                  color="indigo"
                  class="headline font-weight-light white--text"
                >
                  {{ item.name.charAt(0) }}
                </v-list-item-avatar>
                <v-list-item-content>
                  <v-list-item-title v-text="item.name"></v-list-item-title>
                  <v-list-item-subtitle
                    v-text="item.region.name"
                  ></v-list-item-subtitle>
                </v-list-item-content>
              </template>
            </v-autocomplete>
          </v-card-text>
          <v-divider />
          <v-card-actions class="pa-5">
            <v-btn class="primary" @click="updateProfileData">Обновить</v-btn>
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import ProfilePortfolio from "@/components/Profile/ProfilePortfolio";
import ProfileOrders from "@/components/Profile/ProfileOrders";
const USER_DATA_FORM = {
  firstName: null,
  lastName: null,
  middleName: null,
  email: null,
  phoneNumber: null,
  cityID: null
};
export default {
  name: "Profile",
  components: { ProfileOrders, ProfilePortfolio },
  data() {
    return {
      userData: {
        avatar: null,
        passportActive: false,
        phoneActive: false,
        id: 0,
        emailActive: false,
        lastName: "",
        middleName: "",
        firstName: "",
        phoneNumber: "",
        email: "",
        role: ""
      },
      cities: [],
      loadingAvatar: false,
      disabledForm: true,
      USER_DATA_FORM,
      userDataDialog: false
    };
  },
  watch: {
    userDataDialog(value) {
      if (value) {
        this.loadCities();
      }
    }
  },
  mounted() {
    this.loadData();
  },
  methods: {
    loadData() {
      this.$axios.get("user/").then(r => {
        this.userData = { ...r.data.data };
        this.stopLoading();
      });
    },
    loadCities() {
      this.$axios.get(`region/city/search?query=&size=1000`).then(r => {
        this.cities = r.data.data.content;
      });
    },
    editProfileData() {
      const {
        lastName,
        middleName,
        firstName,
        phoneNumber,
        email
      } = this.userData;
      this.USER_DATA_FORM = {
        lastName,
        middleName,
        firstName,
        phoneNumber,
        email,
        cityID: this.userData.city === null ? null : this.userData.city.id
      };
      this.userDataDialog = true;
    },
    updateProfileData() {
      if (this.$refs.userDataForm.validate()) {
        this.$axios
          .put("/user/update", { ...this.USER_DATA_FORM })
          .then(async r => {
            this.userDataDialog = false;
            this.USER_DATA_FORM = { ...USER_DATA_FORM };
            await this.startLoading();
            await this.loadData();
            await this.stopLoading();
          });
      }
    },
    saveAvatar(avatar) {
      this.$axios
        .put("user/update", {
          avatar: avatar
        })
        .then(async () => {
          this.loadData();
          this.loadingAvatar = false;
        });
    },
    removeAvatar() {
      this.loadingAvatar = true;
      this.saveAvatar(null);
    },
    prepareAvatar(event) {
      this.loadingAvatar = true;
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onload = e => {
        const avatar = e.target.result.replace(
          /^data:image\/[a-z]+;base64,/,
          ""
        );
        this.saveAvatar(avatar);
      };
      reader.readAsDataURL(file);
    }
  }
};
</script>

<style lang="scss" scoped>
.profile-item {
  background-color: lighten(#4caf50, 45%);
  border-radius: 50%;
  height: 100px;
  width: 100px;
  display: flex;
  flex-direction: column;
  padding: 10px;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
  &_red {
    background-color: lighten(#f44336, 35%);
  }
}
.avatar {
  width: 100%;
  background-color: #f8f8f8;
  position: relative;
  padding-bottom: 100%;
  border-radius: 4px;
  border: 1px dashed darken(#f8f8f8, 20%);
  span {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
  }
}
.avatar-btns {
  position: absolute;
  right: -10px;
  top: -10px;
}
.avatar-btn:first-child {
  margin-right: 5px;
}
.avatar-progress {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
}
.avatar-img {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.avatar-select {
  display: none;
}
</style>
