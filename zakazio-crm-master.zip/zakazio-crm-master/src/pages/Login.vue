<template>
  <v-card class="mx-auto" flat>
    <v-form @submit.prevent="login()">
      <!-- <v-card-title>Вход в CRM</v-card-title>
      <v-divider />-->
      <v-card-text class="pt-2 pb-0 px-0">
        <v-alert :value="loginError" transition="fade-transition" type="error">
          Неверный логин или пароль!
        </v-alert>
        <v-text-field
          v-if="STEP === STEPS.LOGIN"
          v-model="FORM.email"
          prepend-inner-icon="mdi-email-outline"
          outlined
          label="Электронная почта"
          placeholder="example@example.com"
        />
        <v-text-field
          v-if="STEP === STEPS.PASSWORD"
          v-model="FORM.password"
          prepend-inner-icon="mdi-form-textbox-password"
          outlined
          type="password"
          label="Пароль"
          placeholder="******"
        />
      </v-card-text>
      <v-card-actions class="px-0 d-block">
        <div class="d-flex flex align-center justify-center mb-5">
          <v-btn
            rounded
            :loading="loading"
            :disabled="
              (FORM.email === '' && STEP === STEPS.LOGIN) ||
                (FORM.password === '' && STEP === STEPS.PASSWORD)
            "
            type="submit"
            color="primary"
            x-large
            depressed
            class="mr-3"
          >
            {{ STEP === STEPS.LOGIN ? "Далее" : "Войти" }}
          </v-btn>
          <v-btn to="/register" text>
            Регистрация
          </v-btn>
        </div>
        <div class="d-flex flex align-center justify-center">
          <v-btn to="/forgot" text>
            Забыли пароль?
          </v-btn>
        </div>
      </v-card-actions>
    </v-form>
  </v-card>
</template>

<script>
const FORM = {
  email: "",
  password: ""
};
const STEPS = {
  LOGIN: "LOGIN",
  PASSWORD: "PASSWORD"
};
export default {
  name: "Login",
  data() {
    return {
      loginError: false,
      FORM: { ...FORM },
      STEP: STEPS.LOGIN,
      STEPS,
      loading: false
    };
  },
  /* created() {
    var myHeaders = new Headers();
    myHeaders.append(
      "Authorization",
      "Bearer eyJhbGciOiJIUzI1NiJ9.eyJpZCI6MSwiZk5hbWUiOiJOaWtvbGF5IiwibE5hbWUiOiJLb3psb3YiLCJtTmFtZSI6IlNlcmdlZXZpY2giLCJleHAiOjE2MDY0OTY1ODN9.SHiEkaHYnE6u4q3KGAO-taOD1Ni8mJ3yegu6URM8KSI"
    );

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow"
    };

    fetch("http://localhost:8080/api/v1/user/", requestOptions)
      .then(response => response.text())
      .then(result => console.log(result))
      .catch(error => console.log("error", error));
  }, */
  methods: {
    login() {
      if (this.STEP === STEPS.LOGIN) {
        return (this.STEP = STEPS.PASSWORD);
      }
      this.loading = true;
      this.$axios
        .post("user/login", this.FORM)
        .then(response => {
          const token = `Bearer ${response.data.data.token}`;
          this.$axios
            .get("user/", {
              headers: {
                Authorization: token,
                Accept: "application/json"
              }
            })
            .then(response => {
              this.loading = false;
              const userData = response.data.data;
              this.$store.dispatch("login", { ...userData, token });
              this.$router.push("/");
            })
            .catch(error => console.log(JSON.stringify(error)));
        })
        .catch(() => {
          this.loginError = true;
          this.loading = false;
          setTimeout(() => {
            this.loginError = false;
          }, 2000);
        });
    }
  }
};
</script>
