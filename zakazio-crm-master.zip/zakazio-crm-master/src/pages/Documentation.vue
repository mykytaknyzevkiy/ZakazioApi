<template>
  <v-container>
    <v-card outlined class="mb-3">
      <v-card-text>
        APP_KEY - это публичный ключ вашего приложения, который вы получаете при
        создании приложения. APP_KEY вашего приложения:
        <kbd>{{ appKey }}</kbd
        >.
      </v-card-text>
    </v-card>
    <router-view :app-key="appKey" :api-url="apiUrl" />
  </v-container>
</template>

<script>
export default {
  name: "Documentation",
  data() {
    return {
      appKey: this.$route.params.id,
      apiUrl: process.env.VUE_APP_API_APP
    };
  }
};
</script>

<style scoped></style>
