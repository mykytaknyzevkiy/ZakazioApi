<template>
  <v-card flat class="mx-auto">
    <v-form @submit.prevent="forgot()">
      <v-card-text class="pt-2 pb-0 px-0">
        <v-text-field
          v-if="STEP === STEPS.EMAIL"
          v-model="FORM.email"
          type="email"
          prepend-inner-icon="mdi-email-outline"
          outlined
          label="Электронная почта"
          placeholder="example@example.com"
          :error-messages="
            emailError ? ['Возможно такой email не найден.'] : []
          "
        />
        <v-alert v-if="STEP === STEPS.CODE" dense type="info" class="mb-7">
          На вашу почту отправлен проверочный код. Введите его.
        </v-alert>
        <v-text-field
          v-if="STEP === STEPS.CODE"
          v-model="FORM.code"
          type="number  "
          prepend-inner-icon="mdi-code-tags"
          outlined
          label="Код подтверждения"
          placeholder="0000"
          :error-messages="codeError ? ['Неверный код подтверждения.'] : []"
        />
      </v-card-text>
      <template v-if="STEP === STEPS.DONE">
        <v-alert dense type="info" icon="mdi-check">
          На вашу почту отправлен новый пароль.
        </v-alert>
      </template>
      <v-card-actions class="px-0 d-block">
        <div class="d-flex flex align-center justify-center mb-5">
          <v-btn
            v-if="STEP !== STEPS.DONE"
            :loading="loading"
            rounded
            type="submit"
            color="primary"
            x-large
            depressed
            class="mr-3"
            :disabled="disabled"
          >
            Далее
          </v-btn>
          <v-btn to="/login" text>
            {{ STEP !== STEPS.DONE ? "Вспомнили пароль?" : "Войти" }}
          </v-btn>
        </div>
      </v-card-actions>
    </v-form>
  </v-card>
</template>

<script>
const FORM = {
  email: "nikolay@velkomb.com",
  code: "",
  token: ""
};
const STEPS = {
  EMAIL: "EMAIL",
  CODE: "CODE",
  DONE: "DONE"
};
export default {
  name: "Forgot",
  data() {
    return {
      emailError: false,
      codeError: false,
      loading: false,
      FORM,
      STEPS,
      STEP: STEPS.EMAIL
    };
  },
  computed: {
    disabled() {
      return (
        (FORM.email === "" && this.STEP === STEPS.EMAIL) ||
        (FORM.code === "" && this.STEP === STEPS.CODE)
      );
    }
  },
  methods: {
    async sendEmail() {
      await this.$axios
        .post("/user/reset/password", {
          email: FORM.email
        })
        .then(response => {
          this.loading = false;
          this.FORM.token = response.data.data.token;
          this.STEP = STEPS.CODE;
        })
        .catch(() => {
          this.loading = false;
          return (this.emailError = true);
        });
    },
    async sendCode() {
      await this.$axios
        .post("/user/reset/password", {
          token: FORM.token,
          code: FORM.code
        })
        .then(() => {
          this.loading = false;
          this.STEP = STEPS.DONE;
        })
        .catch(() => {
          this.loading = false;
          return (this.codeError = true);
        });
    },
    forgot() {
      this.loading = true;
      if (this.STEP === STEPS.EMAIL) {
        this.sendEmail();
      } else {
        this.sendCode();
      }
    }
  }
};
</script>
