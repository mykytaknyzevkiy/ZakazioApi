import Vue from "vue";
const moment = require("moment");
require("moment/locale/ru");

export default Vue.use(require("vue-moment"), {
  moment
});
