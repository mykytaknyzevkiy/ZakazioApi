import Vue from "vue";
import { AclInstaller, AclCreate, AclRule } from "vue-acl";
import router from "../router";
import store from "../store";

Vue.use(AclInstaller);
const getRole = store => {
  if (!store.getters.isAuthenticated) {
    return "anonymous";
  }
  if (store.getters.userData.partner) {
    return "partner";
  }
};
export default new AclCreate({
  initial: "public",
  notfound: {
    path: "/error",
    forwardQueryParams: true
  },
  router,
  acceptLocalRules: true,
  globalRules: {
    // isAdmin: new AclRule("admin").generate(),
    // isLogged: new AclRule("user").generate(),
    isLogged: new AclRule("user").or("admin").or("partner"), // расширить другими ролями
    isPublic: new AclRule("public").generate(),
    notLoggedRule: new AclRule("anonymous").generate(),
    applicationsAccess: new AclRule("partner").generate(),
    ordersAccess: new AclRule("partner").generate()
  },
  middleware: async acl => {
    // await timeout(2000); // call your api
    const role = getRole(store);
    acl.change([role, "public"]);
  }
});
