import firebase from "firebase";

const config = {
  apiKey: "AIzaSyB3oEdhcmf18rBVs0hPuv4FxpONIYATFJ0",
  authDomain: "zakazio-56c70.firebaseapp.com",
  databaseURL: "https://zakazio-56c70.firebaseio.com",
  projectId: "zakazio-56c70",
  storageBucket: "zakazio-56c70.appspot.com",
  messagingSenderId: "548924249412",
  appId: "1:548924249412:web:1f89dfcdd3b94df270b311",
  measurementId: "G-QKMNS00EG0"
};

firebase.initializeApp(config);

export default {
  messaging: firebase.messaging()
};
