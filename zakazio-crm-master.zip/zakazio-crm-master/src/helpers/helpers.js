export const hasProp = (obj, val) =>
  Object.prototype.hasOwnProperty.call(obj, val) && obj[val] !== undefined;
export const parseError = errObj => JSON.parse(JSON.stringify(errObj));
