<template>
  <default-layout v-if="!$route.meta.layout" />
  <login-layout v-else />
</template>
<script>
import DefaultLayout from "@/layouts/default";
import LoginLayout from "@/layouts/login";

/* import Vue from "vue";
import LoadScript from "vue-plugin-load-script";

Vue.use(LoadScript);

const firebaseConfig = {
  apiKey: "AIzaSyB3oEdhcmf18rBVs0hPuv4FxpONIYATFJ0",
  authDomain: "zakazio-56c70.firebaseapp.com",
  databaseURL: "https://zakazio-56c70.firebaseio.com",
  projectId: "zakazio-56c70",
  storageBucket: "zakazio-56c70.appspot.com",
  messagingSenderId: "548924249412",
  appId: "1:548924249412:web:f1f59a3d001ed82370b311",
  measurementId: "G-LH9V4HJVQQ"
}; */

export default {
  components: { LoginLayout, DefaultLayout }
  /* created() {
    Promise.resolve()
      .then(() =>
        Vue.loadScript(
          "https://www.gstatic.com/firebasejs/7.14.0/firebase-app.js"
        )
      )
      .then(() =>
        Vue.loadScript(
          "https://www.gstatic.com/firebasejs/7.14.0/firebase-messaging.js"
        )
      )
      .then(() =>
        Vue.loadScript(
          "https://www.gstatic.com/firebasejs/7.14.0/firebase-analytics.js"
        )
      )
      .then(() => {
        if (!window.firebase.apps.length) {
          window.firebase.initializeApp(firebaseConfig);
        } else {
          window.firebase.app(); // if already initialized, use that one
        }

        const messaging = window.firebase.messaging();
        Notification.requestPermission().then(permission => {
          if (permission === "granted") {
            messaging
              .getToken({
                vapidKey:
                  "BDVX_zSTSqRmOlVwLFW3cnbPReytQtmQ3um1VPZ00BmiwmMnQuLNBZjdmJ93UIqQkpNRtGa_1aj2xxxTbLrnmF0"
              })
              .then(token => {
                console.log(token);
              });
          } else {
            console.log("Unable to get permission to notify.");
          }
        });
        /!* messaging.onTokenRefresh(function() {
            messaging.getToken().then(function(refreshedToken) {
              console.log(refreshedToken);
            });
          }); *!/
        messaging.onMessage(payload => {
          console.log("fgjjdg");
          /!* const data = { ...payload.notification, ...payload.data };
          const notificationTitle = data.title;
          const notificationOptions = {
            body: data.body,
            icon: data.icon,
            image: data.image,
            click_action: data.click_action,
            requireInteraction: true,
            data
          };
          console.log(notificationTitle, notificationOptions);
          // eslint-disable-next-line no-new
          new Notification(payload.notification.title, payload.notification); *!/
        });
      });
  } */
};
</script>
