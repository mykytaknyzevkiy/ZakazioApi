import Vue from "vue";
import "./plugins/axios";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import vuetify from "./plugins/vuetify";
import i18n from "./i18n";
import wysiwyg from "vue-wysiwyg";

import "roboto-fontface/css/roboto/roboto-fontface.css";
import "./plugins/moment";
import "./plugins/clipboard";
import "./plugins/prism";
import GlobalMixin from "./mixins/globals";
import "vue-wysiwyg/dist/vueWysiwyg.css";

Vue.use(wysiwyg, {
  maxHeight: "500px",
  image: {
    uploadURL: process.env.VUE_APP_API_ROOT + "/files/save"
  }
});
Vue.mixin(GlobalMixin);
Vue.config.productionTip = false;

const Bus = new Vue({
  router,
  store,
  vuetify,
  i18n,
  render: h => h(App)
}).$mount("#app");
export default Bus;
