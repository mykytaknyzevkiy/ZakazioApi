import router from "../router";
export default {
  state: {
    user: JSON.parse(localStorage.getItem("user")) || {},
    token: localStorage.getItem("token") || ""
  },
  mutations: {
    SET_USER(state, user) {
      state.user = { ...state.user, ...user };
    },
    SET_TOKEN(state, token) {
      state.token = token;
    },
    REMOVE_USER(state) {
      state.user = { ...state.user, ...{} };
    },
    REMOVE_TOKEN(state) {
      state.token = "";
    }
  },
  actions: {
    login(context, user) {
      localStorage.setItem("user", JSON.stringify(user));
      localStorage.setItem("token", user.token);
      context.commit("SET_USER", user);
      context.commit("SET_TOKEN", user.token);
    },
    logout(context) {
      localStorage.removeItem("user");
      localStorage.removeItem("token");
      context.commit("REMOVE_USER");
      context.commit("REMOVE_TOKEN");
      router.push({
        name: "LOGIN",
        query: { redirect: router.app.$route.fullPath }
      });
    }
  },
  getters: {
    token: store => store.token,
    isAuthenticated: state => {
      return state.token !== "" && Object.keys(state.user).length !== 0;
    },
    userData: state => state.user,
    role: state => {
      if (state.token === "" && Object.keys(state.user).length !== 0) {
        return "anonymous";
      }
      return state.user.role;
    }
  }
};
