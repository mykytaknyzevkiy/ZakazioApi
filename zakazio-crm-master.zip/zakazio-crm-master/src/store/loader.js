export default {
  state: {
    loading: false
  },
  mutations: {
    SET_PROCESS(state, value) {
      state.loading = value;
    }
  },
  actions: {
    setLoadingStatus(context, value) {
      context.commit("SET_PROCESS", value);
    }
  },
  getters: {
    getLoaderStatus: state => {
      return state.loading;
    }
  }
};
