export default {
  methods: {
    getRoles(user) {
      const roles = [];
      if (user.admin) roles.push("Администратор");
      if (user.agent) roles.push("Агент");
      if (user.editor) roles.push("Модератор");
      if (user.executor) roles.push("Исполнитель");
      if (user.superAdmin) roles.push("Суперадминистратор");
      if (user.user) roles.push("Пользователь");
      return roles;
    },
    avatarName(user) {
      return user.firstName[0] + user.lastName[0];
    },
    userName(user) {
      return `${user.firstName} ${user.lastName}`;
    }
  }
};
