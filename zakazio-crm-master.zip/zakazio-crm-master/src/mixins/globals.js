import Spinner from "@/components/Spinner";
import { mapGetters } from "vuex";

export default {
  methods: {
    ...mapGetters(["user/login"]),
    startLoading() {
      this.$store.dispatch("setLoadingStatus", true);
    },
    stopLoading() {
      this.$store.dispatch("setLoadingStatus", false);
    }
  },
  computed: {
    me() {
      return this.$store.getters.userData;
    },
    process() {
      return this.$store.getters.getLoaderStatus;
    },
    appUrl() {
      return process.env.VUE_APP_API_APP;
    },
    storageUrl() {
      return `${process.env.VUE_APP_API_ROOT}/file`;
    }
  },
  components: {
    Spinner
  }
};
