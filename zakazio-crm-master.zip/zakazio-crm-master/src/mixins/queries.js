const getPageable = data => {
  const { offset, pageNumber, pageSize, paged, unpaged } = data.pageable;
  return {
    offset,
    pageNumber: pageNumber + 1,
    pageSize,
    paged,
    unpaged,
    totalElements: data.totalElements,
    totalPages: data.totalPages
  };
};
export default {
  data() {
    return {
      activeFilters: {
        page: "1",
        search: ""
      },
      pageable: {
        offset: 0,
        pageNumber: 0,
        pageSize: 0,
        paged: true,
        unpaged: false,
        totalElements: 0,
        totalPages: 0
      }
    };
  },
  methods: {
    getPageable,
    async filterResults(prop, value) {
      const tValue = value.toString();
      if (prop !== "page") {
        this.activeFilters.page = "1";
      }
      this.activeFilters[prop] = tValue;
      if (this.$route.query[prop] !== tValue) {
        await this.$router.replace({
          query: {
            ...this.activeFilters
          }
        });
      }

      await this.startLoading();
      await this.loadData();
    }
  }
};
