export default {
  data() {
    return {
      activeFilters: {
        size: 10
      }
    };
  },
  created() {
    this.activeFilters = {
      ...this.activeFilters,
      ...this.$route.query
    };
  },
  computed: {
    dateRangeText() {
      if (this.dateRange.length === 0) {
        return "Выберите дату";
      }
      return (
        this.$moment(this.dateRange[0]).format("ll") +
        " ~ " +
        this.$moment(this.dateRange[1]).format("ll")
      );
    }
  },
  methods: {
    setDayRange(range) {
      const startDate = this.$moment()
        .subtract(1, range)
        .format("YYYY-MM-DD");
      const endDate = this.$moment().format("YYYY-MM-DD");
      this.filterResults({ start_date: startDate, end_date: endDate });
      this.dateRange = [startDate, endDate];
    },
    clearRange() {
      this.dateRange = [];
      this.deleteFilters(["start_date", "end_date"]);
    },
    selectRange(data) {
      this.filterResults({ start_date: data[0], end_date: data[1] });
      this.dateRange = [...data];
    },
    async deleteFilters(props) {
      for (const prop of props) {
        if (Object.prototype.hasOwnProperty.call(this.activeFilters, prop)) {
          delete this.activeFilters[prop];
        }
      }
      await this.$router.replace({
        query: {
          ...this.activeFilters
        }
      });
      await this.startLoading();
      this.loadData();
    },
    async filterResults(prop, value) {
      this.activeFilters.page = "1";
      if (typeof prop === "object") {
        this.activeFilters = { ...this.activeFilters, ...prop };
      } else if (
        value === "" &&
        Object.prototype.hasOwnProperty.call(this.activeFilters, prop)
      ) {
        delete this.activeFilters[prop];
      } else {
        this.activeFilters = Object.assign({}, this.activeFilters, {
          [prop]: value.toString()
        });
      }
      await this.$router.replace({
        query: {
          ...this.activeFilters
        }
      });
      await this.startLoading();
      this.loadData();
    }
  }
};
