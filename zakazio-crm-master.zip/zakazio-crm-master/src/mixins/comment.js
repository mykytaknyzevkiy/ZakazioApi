import DialogSpinner from "@/components/DialogSpinner";
const FORM = {};
export default {
  components: { DialogSpinner },
  data() {
    return {
      loading: false,
      dialog: false
    };
  },
  beforeDestroy() {
    this.$off("commentWasAdded");
  },
  created() {
    this.$root.$on("commentWasAdded", () => this.cancel());
  },
  methods: {
    cancel() {
      this.loading = false;
      this.dialog = false;
      // eslint-disable-next-line no-undef
      this.FORM = { ...FORM };
    }
  }
};
