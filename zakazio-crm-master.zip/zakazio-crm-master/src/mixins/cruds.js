const ACTIONS = {
  CREATE_ACTION: "CREATE_ACTION",
  EDIT_ACTION: "EDIT_ACTION",
  DELETE_ACTION: "DELETE_ACTION",
  NO_ACTION: "NO_ACTION"
};
const ACTIONS_ALIASES = {
  CREATE_ACTION: "Создание",
  EDIT_ACTION: "Редактирование",
  DELETE_ACTION: "Удаление",
  NO_ACTION: null
};
export default {
  data() {
    return {
      DIALOG: false,
      LOADING: false,
      ACTIONS,
      ACTIONS_ALIASES,
      ACTION: ACTIONS.NO_ACTION
    };
  },
  watch: {
    DIALOG(value) {
      if (!value) {
        this.resetForm();
      }
    }
  }
};
