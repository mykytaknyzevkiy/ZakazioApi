<template>
  <v-app class="bg-col">
    <v-container fluid class="fill-height py-0">
      <v-row class="fill-height">
        <v-col class="col-5 d-flex flex-column justify-center">
          <h1 class="page-title">
            <img
              src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHhtbG5zOnN2Z2pzPSJodHRwOi8vc3ZnanMuY29tL3N2Z2pzIiB3aWR0aD0iNTEyIiBoZWlnaHQ9IjUxMiIgeD0iMCIgeT0iMCIgdmlld0JveD0iMCAwIDkyOS41NDggOTI5LjU0OSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEyIDUxMiIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgY2xhc3M9IiI+PGc+CjxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+Cgk8Zz4KCQk8cGF0aCBkPSJNMTUyLjk2NCw5MjIuODUzbDI5NS43NDMtMzI2LjMwN0wzNDEuNTY2LDQ4OS40MDRDMTg3LjcxNiw2MjguODQ1LDI0LjQyNCw3NzYuODQyLDE1LjYzMSw3ODQuODEyICAgIGMtMC4yNTEsMC4yMjgtMC40OTQsMC40NTctMC43MjksMC43MDJjLTkuNzQzLDEwLjItOC4wOSwyNy45MDEsMy44MTUsMzkuODA3bDk0LjA3NCw5NC4wNzQgICAgQzEyNC44NCw5MzEuNDQyLDE0Mi44MjYsOTMyLjk5MSwxNTIuOTY0LDkyMi44NTN6IiBmaWxsPSIjZmZmZmZmIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBzdHlsZT0iIiBjbGFzcz0iIj48L3BhdGg+CgkJPHBhdGggZD0iTTY5NS44MTYsMzIzLjg5OWMwLjIxMy0wLjIzNSwwLjQzNC0wLjQ2NiwwLjY2MS0wLjY4N2MyNS45OTMtMjUuMjU3LDY2LjE5Ny0yMi45MTEsOTUuNTY4LTQyLjUzMyAgICBjMjMuMTkyLTE1LjQ5NSwzNi45OS00OS44MDEsNTEuMTg4LTczLjE0YzIzLjEwMy0zNy45NzQsNDYuMjA0LTc1Ljk0OSw2OS4zMDYtMTEzLjkyM2MzLjIxOS01LjI5LDIuMzk5LTEyLjA5LTEuOTc5LTE2LjQ2OSAgICBsLTQ5LjU5Ny00OS41OTZjLTQuMzc4LTQuMzc4LTExLjE4NC01LjE5NS0xNi40NzMtMS45NzdjLTM5LjQ0NSwyMy45OTctNzguODkzLDQ3Ljk5NS0xMTguMzM5LDcxLjk5MiAgICBjLTI0LjgxMywxNS4wOTYtNTMuOTA5LDI3Ljc2Ni03MC45OTQsNTIuMzhjLTE5LjU5MSwyOC4yMjUtMTUuMTQyLDY2LjE0Ny00MC41NzgsOTIuMDE0ICAgIGMtMC4wMDMsMC4wMDMtNDguOTk0LDQ0LjQwNi0xMTguOTUzLDEwNy44MTNsOTIuNzExLDkyLjcxMUw2OTUuODE2LDMyMy44OTl6IiBmaWxsPSIjZmZmZmZmIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBzdHlsZT0iIiBjbGFzcz0iIj48L3BhdGg+CgkJPHBhdGggZD0iTTU3MS41MjksNDYxLjAzMWwtOTQuNDQ4LTk0LjQ0OEwzNzQuMDAyLDI2My41MDVjMS42NTQtNC4zNTYsMy4xNDUtOC43Niw0LjQ3NS0xMy4yMDMgICAgYzEuMzg5LTQuNjQsMi42MDUtOS4zMjIsMy42NDItMTQuMDM2YzEzLjc3Mi02Mi42NDMtMy41OTUtMTMwLjg4NS01Mi4xMDgtMTc5LjM5OUMyNzEuMjI3LTEuOTE2LDE4NC4xMzItMTUuMTI1LDExMi42MjEsMTcuMjMyICAgIGMtMTEuODgyLDUuMzc2LTE0LjcxOCwyMC45ODEtNS40OTcsMzAuMjAzbDEyMC4yNTEsMTIwLjI1MWMxNC42MjUsMTQuNjI1LDE0LjYyNSwzOC4zMzgsMCw1Mi45NjNMMTA3LDM0MS4wMjQgICAgYy05LjE2MSw5LjE2MS02LjMzOSwyNC42NTQsNS40NjEsMzAuMDA2YzM4LjgxOCwxNy42MDcsODIuMjM5LDIxLjc3MiwxMjMuMjM4LDEyLjUwN2M0LjY5Mi0xLjA2LDkuMzUxLTIuMjk3LDEzLjk2OS0zLjcwOSAgICBjNC40MjEtMS4zNTIsOC44MDItMi44NjYsMTMuMTM3LTQuNTQxbDk3LjMwOCw5Ny4zMDlsMTA1LjQwNCwxMDUuNDAzTDgwNC43NSw5MTcuMjMzYzQuODc3LDQuODc3LDExLjI3MSw3LjMxNiwxNy42NjIsNy4zMTYgICAgYzYuMzkzLDAsMTIuNzg1LTIuNDM4LDE3LjY2Mi03LjMxNmw3Ni4xNjYtNzYuMTY2YzkuNzU1LTkuNzU1LDkuNzU1LTI1LjU3LDAtMzUuMzI0TDU3MS41MjksNDYxLjAzMXogTTgxNy41NDcsODUyLjA4ICAgIGMtMTcuNjc0LDAtMzItMTQuMzI3LTMyLTMyczE0LjMyNi0zMiwzMi0zMmMxNy42NzMsMCwzMiwxNC4zMjcsMzIsMzJTODM1LjIyLDg1Mi4wOCw4MTcuNTQ3LDg1Mi4wOHoiIGZpbGw9IiNmZmZmZmYiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGNsYXNzPSIiPjwvcGF0aD4KCQk8cGF0aCBkPSJNODAuNjA4LDMwOS4yNDhsNzkuNTg2LTc5LjU4NmM4LjI1NS04LjI1Niw4LjI1NS0yMS42NDEsMC0yOS44OTZMNDguMTk5LDg3Ljc3MWMtNS45NDUtNS45NDUtMTUuOTUzLTQuMzgxLTE5LjgxNywzLjA4NSAgICBDLTcuMjgxLDE1OS43NzEtMC4zNDIsMjQ1LjAxOSw0OS4yMDYsMzA3LjU3M0M1Ny4wMDcsMzE3LjQyMiw3MS43MjMsMzE4LjEzMSw4MC42MDgsMzA5LjI0OHoiIGZpbGw9IiNmZmZmZmYiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIHN0eWxlPSIiIGNsYXNzPSIiPjwvcGF0aD4KCTwvZz4KPC9nPgo8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8L2c+CjxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjwvZz4KPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPC9nPgo8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8L2c+CjxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjwvZz4KPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPC9nPgo8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8L2c+CjxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjwvZz4KPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPC9nPgo8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8L2c+CjxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjwvZz4KPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPC9nPgo8ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8L2c+CjxnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjwvZz4KPGcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPC9nPgo8L2c+PC9zdmc+"
            />
            <span>ZAKAZIO.RU</span>
          </h1>
          <hr class="page-hr" />
          <p class="page-slogan">
            Помогаем бизнесу <br />
            работать :)
          </p>
        </v-col>
        <v-col
          class="col-7 white align-center d-flex flex-column justify-center"
        >
          <v-card class="mt-auto mb-auto" max-width="900" flat>
            <h1 class="mb-8">
              {{
                $route.name === "Register"
                  ? "Регистрация в CRM"
                  : $route.name === "Login"
                  ? "Авторизация в CRM"
                  : "Восстановление пароля"
              }}
            </h1>

            <router-view />
          </v-card>
          <div class="page-links">
            <a href="#">Контакты</a>
            <a href="#">Помощь</a>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </v-app>
</template>

<script>
export default {
  name: "LoginLayout"
};
</script>

<style scoped>
.page-links {
  justify-self: flex-end;
  margin-top: auto;
  margin-bottom: 0;
  display: flex;
  justify-content: flex-end;
}
.page-links > a {
  margin-right: 10px;
  margin-left: 10px;
  font-size: 18px;
}
.bg-col {
  background-color: #1976d2;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='192' height='192' viewBox='0 0 192 192'%3E%3Cpath fill='%23004b9f' fill-opacity='0.4' d='M192 15v2a11 11 0 0 0-11 11c0 1.94 1.16 4.75 2.53 6.11l2.36 2.36a6.93 6.93 0 0 1 1.22 7.56l-.43.84a8.08 8.08 0 0 1-6.66 4.13H145v35.02a6.1 6.1 0 0 0 3.03 4.87l.84.43c1.58.79 4 .4 5.24-.85l2.36-2.36a12.04 12.04 0 0 1 7.51-3.11 13 13 0 1 1 .02 26 12 12 0 0 1-7.53-3.11l-2.36-2.36a4.93 4.93 0 0 0-5.24-.85l-.84.43a6.1 6.1 0 0 0-3.03 4.87V143h35.02a8.08 8.08 0 0 1 6.66 4.13l.43.84a6.91 6.91 0 0 1-1.22 7.56l-2.36 2.36A10.06 10.06 0 0 0 181 164a11 11 0 0 0 11 11v2a13 13 0 0 1-13-13 12 12 0 0 1 3.11-7.53l2.36-2.36a4.93 4.93 0 0 0 .85-5.24l-.43-.84a6.1 6.1 0 0 0-4.87-3.03H145v35.02a8.08 8.08 0 0 1-4.13 6.66l-.84.43a6.91 6.91 0 0 1-7.56-1.22l-2.36-2.36A10.06 10.06 0 0 0 124 181a11 11 0 0 0-11 11h-2a13 13 0 0 1 13-13c2.47 0 5.79 1.37 7.53 3.11l2.36 2.36a4.94 4.94 0 0 0 5.24.85l.84-.43a6.1 6.1 0 0 0 3.03-4.87V145h-35.02a8.08 8.08 0 0 1-6.66-4.13l-.43-.84a6.91 6.91 0 0 1 1.22-7.56l2.36-2.36A10.06 10.06 0 0 0 107 124a11 11 0 0 0-22 0c0 1.94 1.16 4.75 2.53 6.11l2.36 2.36a6.93 6.93 0 0 1 1.22 7.56l-.43.84a8.08 8.08 0 0 1-6.66 4.13H49v35.02a6.1 6.1 0 0 0 3.03 4.87l.84.43c1.58.79 4 .4 5.24-.85l2.36-2.36a12.04 12.04 0 0 1 7.51-3.11A13 13 0 0 1 81 192h-2a11 11 0 0 0-11-11c-1.94 0-4.75 1.16-6.11 2.53l-2.36 2.36a6.93 6.93 0 0 1-7.56 1.22l-.84-.43a8.08 8.08 0 0 1-4.13-6.66V145H11.98a6.1 6.1 0 0 0-4.87 3.03l-.43.84c-.79 1.58-.4 4 .85 5.24l2.36 2.36a12.04 12.04 0 0 1 3.11 7.51A13 13 0 0 1 0 177v-2a11 11 0 0 0 11-11c0-1.94-1.16-4.75-2.53-6.11l-2.36-2.36a6.93 6.93 0 0 1-1.22-7.56l.43-.84a8.08 8.08 0 0 1 6.66-4.13H47v-35.02a6.1 6.1 0 0 0-3.03-4.87l-.84-.43c-1.59-.8-4-.4-5.24.85l-2.36 2.36A12 12 0 0 1 28 109a13 13 0 1 1 0-26c2.47 0 5.79 1.37 7.53 3.11l2.36 2.36a4.94 4.94 0 0 0 5.24.85l.84-.43A6.1 6.1 0 0 0 47 84.02V49H11.98a8.08 8.08 0 0 1-6.66-4.13l-.43-.84a6.91 6.91 0 0 1 1.22-7.56l2.36-2.36A10.06 10.06 0 0 0 11 28 11 11 0 0 0 0 17v-2a13 13 0 0 1 13 13c0 2.47-1.37 5.79-3.11 7.53l-2.36 2.36a4.94 4.94 0 0 0-.85 5.24l.43.84A6.1 6.1 0 0 0 11.98 47H47V11.98a8.08 8.08 0 0 1 4.13-6.66l.84-.43a6.91 6.91 0 0 1 7.56 1.22l2.36 2.36A10.06 10.06 0 0 0 68 11 11 11 0 0 0 79 0h2a13 13 0 0 1-13 13 12 12 0 0 1-7.53-3.11l-2.36-2.36a4.93 4.93 0 0 0-5.24-.85l-.84.43A6.1 6.1 0 0 0 49 11.98V47h35.02a8.08 8.08 0 0 1 6.66 4.13l.43.84a6.91 6.91 0 0 1-1.22 7.56l-2.36 2.36A10.06 10.06 0 0 0 85 68a11 11 0 0 0 22 0c0-1.94-1.16-4.75-2.53-6.11l-2.36-2.36a6.93 6.93 0 0 1-1.22-7.56l.43-.84a8.08 8.08 0 0 1 6.66-4.13H143V11.98a6.1 6.1 0 0 0-3.03-4.87l-.84-.43c-1.59-.8-4-.4-5.24.85l-2.36 2.36A12 12 0 0 1 124 13a13 13 0 0 1-13-13h2a11 11 0 0 0 11 11c1.94 0 4.75-1.16 6.11-2.53l2.36-2.36a6.93 6.93 0 0 1 7.56-1.22l.84.43a8.08 8.08 0 0 1 4.13 6.66V47h35.02a6.1 6.1 0 0 0 4.87-3.03l.43-.84c.8-1.59.4-4-.85-5.24l-2.36-2.36A12 12 0 0 1 179 28a13 13 0 0 1 13-13zM84.02 143a6.1 6.1 0 0 0 4.87-3.03l.43-.84c.8-1.59.4-4-.85-5.24l-2.36-2.36A12 12 0 0 1 83 124a13 13 0 1 1 26 0c0 2.47-1.37 5.79-3.11 7.53l-2.36 2.36a4.94 4.94 0 0 0-.85 5.24l.43.84a6.1 6.1 0 0 0 4.87 3.03H143v-35.02a8.08 8.08 0 0 1 4.13-6.66l.84-.43a6.91 6.91 0 0 1 7.56 1.22l2.36 2.36A10.06 10.06 0 0 0 164 107a11 11 0 0 0 0-22c-1.94 0-4.75 1.16-6.11 2.53l-2.36 2.36a6.93 6.93 0 0 1-7.56 1.22l-.84-.43a8.08 8.08 0 0 1-4.13-6.66V49h-35.02a6.1 6.1 0 0 0-4.87 3.03l-.43.84c-.79 1.58-.4 4 .85 5.24l2.36 2.36a12.04 12.04 0 0 1 3.11 7.51A13 13 0 1 1 83 68a12 12 0 0 1 3.11-7.53l2.36-2.36a4.93 4.93 0 0 0 .85-5.24l-.43-.84A6.1 6.1 0 0 0 84.02 49H49v35.02a8.08 8.08 0 0 1-4.13 6.66l-.84.43a6.91 6.91 0 0 1-7.56-1.22l-2.36-2.36A10.06 10.06 0 0 0 28 85a11 11 0 0 0 0 22c1.94 0 4.75-1.16 6.11-2.53l2.36-2.36a6.93 6.93 0 0 1 7.56-1.22l.84.43a8.08 8.08 0 0 1 4.13 6.66V143h35.02z'%3E%3C/path%3E%3C/svg%3E");

  /*background-image: url("~@/assets/login.svg");
  background-size: cover;
  background-repeat: no-repeat;
  background-position-y: bottom;
  background-position-x: right;*/
}
.page-hr {
  width: calc(100% - 300px);
  height: 2px;
  margin: 30px auto 40px;
  border: none;
  background-color: #fff;
}
.page-slogan {
  font-family: "Ubuntu", sans-serif;
  text-align: center;
  font-size: 30px;
  line-height: 35px;
  margin: 0 20px 20px;
  color: white;
  font-weight: 300;
}
.page-icons {
  margin: auto 0 0 0;
  color: #fff;
  font-size: 30px;
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: space-around;
}
.page-icon {
  width: 52px;
  height: 52px;
}
.page-icons > span {
  margin-left: 20px;
  margin-right: 20px;
}
.page-title {
  font-family: "Ubuntu", sans-serif;
  color: #ffffff;
  font-size: 25px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  border: 2px solid #fff;
  padding: 13px;
  margin: 20px auto;
  flex-shrink: 1;
  flex-grow: 0;
  border-radius: 5px;
  font-weight: 700;
}
.page-title > img {
  width: 43px;
  height: 43px;
  margin-right: 16px;
}
</style>
