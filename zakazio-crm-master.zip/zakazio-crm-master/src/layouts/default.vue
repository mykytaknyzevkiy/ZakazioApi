<template>
  <v-app app class="grey lighten-4">
    <the-nav />
    <v-main class="grey lighten-4 fill-height">
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
import TheNav from "@/components/TheNav";
export default {
  name: "DefaultLayout",
  components: { TheNav }
};
</script>
