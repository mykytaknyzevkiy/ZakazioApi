import Vue from "vue";
import VueRouter from "vue-router";
import Home from "@/pages/Home.vue";
import store from "@/store";
// import { AclRule } from "vue-acl";

Vue.use(VueRouter);

const authenticationRequiredGuard = (to, from, next) => {
  if (store.getters.isAuthenticated) {
    next(); // allow to enter route
  } else {
    next("/login"); // go to '/login';
  }
};
const authenticationDeniedGuard = (to, from, next) => {
  if (!store.getters.isAuthenticated) {
    next(); // allow to enter route
  } else {
    next("/"); // go to '/login';
  }
};
const usersSectionRoles = [
  "SUPER_ADMIN",
  "ADMIN",
  "EDITOR",
  "PARTNER",
  "AGENT",
  "EXECUTOR",
  "USER"
];
const usersPartnersSectionRoles = ["SUPER_ADMIN", "ADMIN", "EDITOR"];
const usersExecutorsSectionRoles = [
  "SUPER_ADMIN",
  "ADMIN",
  "EDITOR",
  "PARTNER"
];
const passportsSectionRoles = ["SUPER_ADMIN", "ADMIN"];
const usersClientsSectionRoles = ["SUPER_ADMIN", "ADMIN", "EDITOR", "PARTNER"];
const usersEditorsSectionRoles = ["SUPER_ADMIN", "ADMIN", "EDITOR"];
const usersAdminsSectionRoles = ["SUPER_ADMIN", "ADMIN"];

const categoriesSectionRoles = ["SUPER_ADMIN", "ADMIN", "EDITOR"];
const appsSectionRoles = ["SUPER_ADMIN", "ADMIN", "EDITOR", "PARTNER"];
const ordersSectionRoles = [
  "SUPER_ADMIN",
  "ADMIN",
  "EDITOR",
  "PARTNER",
  "AGENT",
  "EXECUTOR"
];
const specialGuard = (to, from, next) => {
  if (!store.getters.isAuthenticated) {
    next("/login");
  } else if (to.meta.roles.includes(store.getters.role)) {
    next();
  } else {
    next("not-allowed");
  }
};

const routes = [
  {
    path: "/",
    name: "Home",
    beforeEnter: authenticationRequiredGuard,
    component: Home
  },
  {
    path: "/login",
    name: "Login",
    beforeEnter: authenticationDeniedGuard,
    component: () => import("@/pages/Login"),
    meta: {
      layout: "login"
    }
  },
  {
    path: "/register",
    name: "Register",
    beforeEnter: authenticationDeniedGuard,
    component: () => import("@/pages/Register"),
    meta: {
      layout: "login"
    }
  },
  {
    path: "/forgot",
    name: "Forgot",
    beforeEnter: authenticationDeniedGuard,
    component: () => import("@/pages/Forgot"),
    meta: {
      layout: "login"
    }
  },
  /*  {
    path: "/users",
    name: "Users",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Users"),
    meta: {
      roles: usersSectionRoles
    }
  }, */
  {
    path: "/admins",
    name: "Admins",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Users"),
    meta: {
      roles: usersAdminsSectionRoles,
      type: "admin"
    }
  },
  {
    path: "/partners",
    name: "Partners",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Users"),
    meta: {
      roles: usersPartnersSectionRoles,
      type: "partner"
    }
  },
  {
    path: "/executors",
    name: "Executors",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Users"),
    meta: {
      roles: usersExecutorsSectionRoles,
      type: "executor"
    }
  },
  {
    path: "/clients",
    name: "Clients",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Users"),
    meta: {
      roles: usersClientsSectionRoles,
      type: "client"
    }
  },
  {
    path: "/editors",
    name: "Editors",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Users"),
    meta: {
      roles: usersEditorsSectionRoles,
      type: "editor"
    }
  },
  {
    path: "/users/:id",
    name: "User",
    beforeEnter: specialGuard,
    component: () => import("@/pages/User"),
    meta: {
      roles: usersSectionRoles
    }
  },
  {
    path: "/categories",
    name: "Categories",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Categories"),
    meta: {
      roles: categoriesSectionRoles
    }
  },

  {
    path: "/apps",
    name: "Applications",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Applications/ApplicationsList"),
    meta: {
      roles: appsSectionRoles
    }
  },
  {
    path: "/apps/create",
    name: "ApplicationsCreate",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Applications/ApplicationsCreate"),
    meta: {
      roles: appsSectionRoles
    }
  },
  {
    path: "/apps/view/:id",
    name: "ApplicationsView",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Applications/ApplicationsView"),
    meta: {
      roles: appsSectionRoles
    }
  },
  {
    path: "/orders",
    name: "Orders",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Orders/OrdersList"),
    meta: {
      roles: ordersSectionRoles
    }
  },
  {
    path: "/orders/add",
    name: "AddOrder",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Orders/OrdersAdd"),
    meta: {
      roles: ordersSectionRoles
    }
  },

  {
    path: "/orders/:id",
    name: "Order",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Orders/OrdersView"),
    meta: {
      roles: ordersSectionRoles
    }
  },
  {
    path: "/orders/:id/set-executor",
    name: "AddOrder",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Orders/OrderSetExecutor"),
    meta: {
      roles: ordersSectionRoles
    }
  },
  {
    path: "/my-orders",
    name: "MyOrders",
    beforeEnter: authenticationRequiredGuard,
    component: () => import("@/pages/Orders/MyOrdersList")
  },
  {
    path: "/passports",
    name: "Passports",
    beforeEnter: specialGuard,
    meta: {
      roles: passportsSectionRoles
    },
    component: () => import("@/pages/Passports")
  },
  {
    path: "/apps/view/:id/docs",
    name: "Documentation",
    beforeEnter: authenticationRequiredGuard,
    component: () => import("@/pages/Documentation"),
    children: [
      {
        path: "orders",
        component: () => import("@/components/Documentation/Orders")
      },
      {
        path: "categories",
        component: () => import("@/components/Documentation/Categories")
      },
      {
        path: "clients",
        component: () => import("@/components/Documentation/Clients")
      },
      {
        path: "executors",
        component: () => import("@/components/Documentation/Executors")
      }
    ]
  },
  {
    path: "/profile",
    name: "Profile",
    beforeEnter: authenticationRequiredGuard,
    component: () => import("@/pages/Profile")
  },
  {
    path: "/verify",
    name: "Verify",
    beforeEnter: authenticationRequiredGuard,
    component: () => import("@/pages/Verify/Verify"),
    children: [
      { path: "", component: () => import("@/pages/NotFound") },
      { path: "phone", component: () => import("@/pages/Verify/VerifyPhone") },
      { path: "email", component: () => import("@/pages/Verify/VerifyEmail") },
      {
        path: "passport",
        component: () => import("@/pages/Verify/VerifyPassport")
      }
    ]
  },
  {
    path: "/regions",
    name: "Regions",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Locations/Regions"),
    meta: {
      roles: ["SUPER_ADMIN", "ADMIN"]
    }
  },
  {
    path: "/regions/:id/cities",
    name: "Cities",
    beforeEnter: specialGuard,
    component: () => import("@/pages/Locations/Cities"),
    meta: {
      roles: ["SUPER_ADMIN", "ADMIN"]
    }
  },
  {
    path: "/not-allowed",
    name: "NotAllowed",
    component: () => import("@/pages/NotAllowed")
  },
  {
    path: "*",
    name: "NotFound",
    component: () => import("@/pages/NotFound")
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

/* router.beforeEach((to, from, next) => {
  if (to.name === "Login") {
    if (store.getters.isAuthenticated) {
      return next({
        path: "/"
      });
    }
    return next();
  }
  if (!store.getters.isAuthenticated) {
    return next({
      path: "/login"
    });
  }
  return next();
}); */

export default router;
