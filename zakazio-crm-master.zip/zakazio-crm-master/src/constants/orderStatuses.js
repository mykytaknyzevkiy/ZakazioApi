export const ORDER_STATUSES = {
  PROCESS: {
    value: "PROCESS",
    name: "Открытый",
    color: "green--text"
  },
  IN_WORK: {
    value: "IN_WORK",
    name: "В работе",
    color: "grey--text"
  },
  CANCEL: {
    value: "CANCEL",
    name: "Отменено",
    color: "red--text"
  },
  DONE: {
    value: "DONE",
    name: "Завершено",
    color: "grey--text"
  }
};
