const ROLES = {
  USER: {
    name: "Пользователь",
    value: "USER",
    icon: "mdi-account-tie"
  },
  CLIENT: {
    name: "Клиент",
    value: "CLIENT",
    icon: "mdi-account-tie"
  },
  PARTNER: {
    name: "Партнер",
    value: "PARTNER",
    icon: "mdi-handshake"
  },
  SUPER_ADMIN: {
    name: "Суперадминистратор",
    value: "SUPER_ADMIN",
    icon: "mdi-crown"
  },
  ADMIN: {
    name: "Администратор",
    value: "ADMIN",
    icon: "mdi-account-star"
  },
  EDITOR: {
    name: "Модератор",
    value: "EDITOR",
    icon: "mdi-account-voice"
  },
  EXECUTOR: {
    name: "Исполнитель",
    value: "EXECUTOR",
    icon: "mdi-shovel"
  }
};

export default ROLES;
