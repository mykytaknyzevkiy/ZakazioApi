const ACTIONS = {
  NO: "NO",
  ADD: "ADD",
  EDIT: "EDIT",
  DELETE: "DELETE"
};
export default ACTIONS;
