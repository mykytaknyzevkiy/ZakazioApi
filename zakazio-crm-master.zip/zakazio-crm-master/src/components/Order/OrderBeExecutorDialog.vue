<template>
  <v-dialog v-model="dialog" persistent max-width="600"
    ><v-form @submit.prevent="submit">
      <v-card class="dialog">
        <dialog-spinner class="dialog" :active="loading" />
        <v-card-title>Детали</v-card-title>
        <v-divider />
        <v-card-text>
          <v-text-field v-model="FORM.price" type="number" placeholder="цена" />
          <v-text-field v-model="FORM.duration" placeholder="срок" />
          <wysiwyg v-model="FORM.comment" placeholder="комментарий" />
        </v-card-text>
        <v-divider />
        <v-card-actions>
          <v-btn
            small
            color="primary"
            :disabled="
              (FORM.price === 0 || FORM.price === null,
              FORM.duration === '' || FORM.comment === '')
            "
            type="submit"
            >Сохранить</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-form></v-dialog
  >
</template>

<script>
import comment from "@/mixins/comment";
const FORM = {
  price: null,
  duration: "",
  comment: ""
};
export default {
  name: "OrderBeExecutorDialog",
  mixins: [comment],
  data() {
    return {
      FORM
    };
  },
  beforeDestroy() {
    this.$off("orderBeExecutorDialog");
  },
  created() {
    this.$root.$on("orderBeExecutorDialog", () => (this.dialog = true));
  },
  methods: {
    submit() {
      const title = "Принял заказ";
      const content = `Цена: ${this.FORM.price} \n Срок: ${this.FORM.duration} \n коментарий: ${this.FORM.comment}`;
      this.loading = true;
      this.$emit("addComment", { title, content });
    }
  }
};
</script>

<style scoped>
.dialog {
  position: relative;
}
</style>
