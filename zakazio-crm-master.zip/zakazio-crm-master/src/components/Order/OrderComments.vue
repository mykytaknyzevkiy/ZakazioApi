<template>
  <v-card style="position: relative" class="mb-3" flat>
    <v-overlay v-show="loading" style="position: absolute">
      <v-progress-circular :size="150" color="white" indeterminate />
    </v-overlay>
    <v-card-title>
      <span>Комментарии к заказу</span>
      <v-spacer />
      <v-btn small @click="addAction">
        Добавить
      </v-btn>
    </v-card-title>
    <template v-if="ACTION === ACTIONS.ADD">
      <v-divider />
      <v-row class="px-3">
        <v-col>
          <v-text-field v-model="FORM.title" placeholder="Заголовок" />
          <wysiwyg v-model="FORM.content" />
          <v-btn
            class="my-3 mr-3"
            color="primary"
            small
            :disabled="FORM.content === '' || FORM.title === ''"
            @click="store"
            >Сохранить</v-btn
          >
          <v-btn small @click="cancel">Отмена</v-btn>
        </v-col>
      </v-row>
    </template>
    <v-divider />
    <template v-for="comment in comments">
      <v-row :key="comment.id" class="px-3">
        <v-col class="col-1">
          <v-avatar class="mr-3" size="45" color="brown lighten-5"
            ><span style="font-size: 10px">{{
              comment.user.firstName[0] + "" + comment.user.lastName[0]
            }}</span></v-avatar
          >
        </v-col>
        <template v-if="FORM.id !== comment.id">
          <v-col class="col-10">
            <div class="d-flex flex-column mb-3">
              <span class="comment-author font-weight-medium">{{
                comment.user.firstName + "" + comment.user.lastName
              }}</span>
              <span class="comment-date">{{
                comment["creationDateTime"] | moment("LLL")
              }}</span>
            </div>
            <h2
              style="font-size: 15px"
              class="font-weight-medium blue-grey--text text--darken-3"
            >
              {{ comment.title }}
            </h2>
            <div
              class="font-weight-light"
              v-html="comment.content.replace(/([^>])\n/g, '$1<br/>')"
            ></div>
          </v-col>
        </template>
      </v-row>
      <v-divider :key="`divider-${comment.id}`" />
    </template>
    <v-row class="px-3">
      <v-col>
        <div class="text-center">
          <v-pagination
            :value="pageNo"
            :length="maxPages"
            circle
            @input="changePage($event)"
          ></v-pagination>
        </div>
      </v-col>
    </v-row>
  </v-card>
</template>

<script>
const ACTIONS = {
  NO: "NO_ACTION",
  ADD: "ADD_ACTION",
  EDIT: "EDIT_ACTION",
  DELETE: "DELETE_ACTION"
};
const FORM = {
  id: null,
  title: "",
  content: ""
};
export default {
  name: "OrderComments",
  props: {
    comments: {
      type: Array
    },
    maxPages: {
      type: Number
    },
    pageNo: {
      type: Number
    }
  },
  data() {
    return {
      loading: false,
      ACTION: ACTIONS.NO,
      ACTIONS,
      FORM
    };
  },
  watch: {
    comments() {
      this.cancel();
    }
  },
  methods: {
    addAction() {
      this.ACTION = ACTIONS.ADD;
      this.FORM = { ...FORM };
    },
    changePage(page) {
      this.loading = true;
      this.$emit("changePage", page);
    },
    store() {
      this.loading = true;
      this.$emit("store", this.FORM);
    },
    cancel() {
      this.loading = false;
      this.ACTION = ACTIONS.NO;
      this.FORM = { ...FORM };
    }
  }
};
</script>

<style scoped>
.comment-date {
  display: inline-block;
  font-size: 13px;
  background: 0;
  padding-left: 0;
  color: #828b95 !important;
}
.comment-author {
  color: #2067b0;
  text-decoration: none;
  font-size: 15px;
}
</style>
