<template>
  <v-dialog v-model="dialog" max-width="600">
    <v-form @submit.prevent="submit">
      <v-card class="dialog">
        <dialog-spinner class="dialog" :active="loading" />
        <v-card-title>Завершение заказа</v-card-title>
        <v-divider />
        <v-card-text>
          <v-text-field v-model="FORM.content" placeholder="комментарий" />
        </v-card-text>
        <v-divider />
        <v-card-actions class="px-5">
          <v-btn
            type="submit"
            small
            color="primary"
            :disabled="FORM.content === ''"
            >Отправить</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-form>
  </v-dialog>
</template>

<script>
import comment from "@/mixins/comment";
const FORM = {
  content: ""
};
export default {
  name: "OrderCloseOrderDialog",
  mixins: [comment],
  data() {
    return {
      FORM
    };
  },

  beforeDestroy() {
    this.$off("orderCloseOrderDialog");
  },
  created() {
    this.$root.$on("orderCloseOrderDialog", () => (this.dialog = true));
  },
  methods: {
    submit() {
      this.loading = true;
      this.$emit("addComment", {
        title: "Завершил заказ (успешно)",
        content: `${this.FORM.content}`
      });
    }
  }
};
</script>

<style scoped>
.dialog {
  position: relative;
}
</style>
