<template>
  <v-card-text class="d-flex">
    <span
      class="mx-auto grey--text text--lighten-2 headline font-weight-regular"
      >нет данных</span
    >
  </v-card-text>
</template>

<script>
export default {
  name: "NoContent"
};
</script>
