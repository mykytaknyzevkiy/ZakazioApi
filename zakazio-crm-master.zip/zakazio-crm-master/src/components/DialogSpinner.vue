<template>
  <v-overlay v-show="active" style="position: absolute">
    <v-progress-circular :size="150" color="white" indeterminate />
  </v-overlay>
</template>

<script>
export default {
  name: "DialogSpinner",
  props: {
    active: {
      type: Boolean,
      default: false
    }
  }
};
</script>

<style scoped></style>
