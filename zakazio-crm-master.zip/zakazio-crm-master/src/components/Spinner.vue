<template>
  <v-overlay v-if="process">
    <v-progress-circular :size="150" color="white" indeterminate />
  </v-overlay>
</template>

<script>
export default {
  name: "Spinner"
};
</script>

<style scoped></style>
