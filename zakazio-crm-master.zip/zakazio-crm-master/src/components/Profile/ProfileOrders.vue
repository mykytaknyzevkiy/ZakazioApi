<template>
  <v-card class="mb-5" flat>
    <v-card-title>
      <span>Заказы</span>
      <v-spacer />
    </v-card-title>
    <v-divider />
    <template v-for="order in orders">
      <router-link
        :key="`order-${order.id}`"
        class="list-link"
        :to="`/orders/${order.id}`"
      >
        <v-row class="px-3">
          <v-col>
            <div class="text-caption grey--text">№ заказа</div>
            <div>{{ order.id }}</div>
          </v-col>
          <v-col>
            <div class="text-caption grey--text">Название</div>
            <div>{{ order.title }}</div>
          </v-col>
          <v-col>
            <div class="text-caption grey--text">Цена</div>
            <div>{{ order.price }}</div>
          </v-col>
          <v-col>
            <div class="text-caption grey--text">Статус</div>
            <div class="d-flex align-center">
              <v-icon
                size="16"
                class="mr-2"
                :class="STATUSES[order.status].color"
                >mdi-circle</v-icon
              >
              {{ STATUSES[order.status].name }}
            </div>
          </v-col>
        </v-row>
      </router-link>
      <v-divider :key="`divider-${order.id}`" />
    </template>
    <template v-if="orders.length === 0">
      <no-content />
    </template>
  </v-card>
</template>

<script>
import { ORDER_STATUSES } from "@/constants/orderStatuses";
import NoContent from "@/components/NoContent";

export default {
  name: "ProfileOrders",
  components: { NoContent },
  data() {
    return {
      STATUSES: ORDER_STATUSES,
      orders: []
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    loadData() {
      this.$axios
        .get(`/order/list/user/${this.me.id}?size=5`)
        .then(response => {
          this.orders = response.data.data.content;
          this.stopLoading();
        });
    }
  }
};
</script>
<style scoped>
.list-link {
  text-decoration: none;
  color: #000;
}
</style>
