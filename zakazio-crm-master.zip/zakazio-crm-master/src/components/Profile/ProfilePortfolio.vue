<template>
  <v-card class="mb-5" flat>
    <v-card-title
      >Портфолио <v-spacer />
      <v-btn
        v-if="mode === 'my'"
        icon
        class="primary"
        @click.prevent="addPortFolio"
        ><v-icon color="white">mdi-file-plus-outline</v-icon></v-btn
      >
    </v-card-title>
    <v-divider />
    <v-row class="mx-3">
      <v-col v-for="pItem in portfolio" :key="pItem.id" class="col-3"
        ><v-card style="position: relative" outlined>
          <v-btn
            v-if="mode === 'my'"
            style="position: absolute; right: 35px; top: -7px; z-index: 2;"
            icon
            class="primary"
            @click.prevent="editPortfolio(pItem)"
            ><v-icon color="white">mdi-file-edit-outline</v-icon></v-btn
          >
          <v-btn
            v-if="mode === 'my'"
            style="position: absolute; right: -7px; top: -7px; z-index: 2;"
            icon
            class="red"
            @click.prevent="deletePortfolio(pItem)"
            ><v-icon color="white">mdi-close</v-icon></v-btn
          >
          <v-card-text class="pa-0">
            <v-img
              aspect-ratio="1"
              :src="`${storageUrl}/${pItem.wallpaper}`"
              @click.prevent="viewPortfolio(pItem, $event)"
            ></v-img
          ></v-card-text>
          <v-card-title class="text-caption">{{ pItem.label }}</v-card-title>
        </v-card>
      </v-col>
    </v-row>
    <v-dialog v-model="viewDialog" max-width="700" scrollable>
      <v-card>
        <v-carousel>
          <v-carousel-item v-for="slide in pItem.imageSlides" :key="slide">
            <v-img :src="`${storageUrl}/${slide}`" />
          </v-carousel-item>
        </v-carousel>
        <v-card-title>
          {{ pItem.label }}
        </v-card-title>
        <v-divider />
        <v-card-text class="py-3">
          {{ pItem.description }}
        </v-card-text>
      </v-card>
    </v-dialog>
    <v-dialog v-model="crudDialog" scrollable persistent max-width="700">
      <v-form
        @submit.prevent="
          ACTION === ACTIONS.CREATE
            ? storeAction()
            : ACTION === ACTIONS.EDIT
            ? updateAction()
            : destroyAction()
        "
      >
        <v-card>
          <v-card-title
            >Создание <v-spacer />
            <v-btn icon @click="crudDialog = false"
              ><v-icon>mdi-close</v-icon></v-btn
            ></v-card-title
          >
          <v-divider />
          <v-card-text class="pa-6">
            <template v-if="ACTION !== ACTIONS.DELETE">
              <v-text-field v-model="FORM.label" label="Заголовок" />
              <v-textarea v-model="FORM.description" label="Описание" />
              <v-card outlined class="mb-3 pa-3 d-flex flex-column">
                <v-file-input
                  accept="image/png,image/jpeg"
                  label="Обложка"
                  clearable
                  @click:clear="TmpImageForm.wallpaper = ''"
                  @change="selectWallpaper($event)"
                />
                <v-img
                  class="mx-auto"
                  max-width="300px"
                  :src="
                    TmpImageForm.wallpaper !== ''
                      ? TmpImageForm.wallpaper
                      : FORM.wallpaper !== ''
                      ? `${storageUrl}/${FORM.wallpaper}`
                      : wallpaperPreview
                  "
                />
              </v-card>
              <v-card outlined class="pa-3"
                ><v-file-input
                  clearable
                  accept="image/png,image/jpeg"
                  label="Слайды"
                  multiple
                  @click:clear="TmpImageForm.imageSlides = []"
                  @change="selectSlides($event)"
                >
                  <template v-slot:selection="{ text }">
                    <v-chip small label color="primary">
                      {{ text }}
                    </v-chip>
                  </template>
                </v-file-input>
                <v-row>
                  <v-col
                    v-for="(slide, n) in TmpImageForm.imageSlides.length !== 0
                      ? TmpImageForm.imageSlides
                      : FORM.imageSlides"
                    :key="n"
                    class="d-flex child-flex"
                    cols="4"
                  >
                    <v-img
                      :src="
                        TmpImageForm.imageSlides.length !== 0
                          ? slide
                          : `${storageUrl}/${slide}`
                      "
                      aspect-ratio="1"
                      class="grey lighten-2"
                    />
                  </v-col>
                </v-row>
              </v-card>
            </template>
            <template v-else>
              <p>Подтверждетете удаление?</p>
            </template>
          </v-card-text>
          <v-divider />
          <v-card-actions class="pa-6">
            <v-btn
              :loading="loading"
              type="submit"
              depressed
              :disabled="disabledForm && ACTION !== ACTIONS.DELETE"
              >Сохранить</v-btn
            >
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
  </v-card>
</template>

<script>
import { mapGetters } from "vuex";
import NoImage from "@/helpers/noImage";
const FORM = {
  id: null,
  label: "",
  description: "",
  wallpaper: "",
  imageSlides: []
};
const TmpImageForm = {
  wallpaper: "",
  imageSlides: []
};
const ACTIONS = {
  EDIT: "EDIT",
  CREATE: "CREATE",
  DELETE: "DELETE",
  NO: "NO"
};
export default {
  name: "ProfilePortfolio",
  props: {
    mode: {
      default: "my" // view
    },
    id: {
      default: null
    }
  },
  data() {
    return {
      loading: false,
      viewDialog: false,
      crudDialog: false,
      portfolio: [],
      pItem: {},
      ACTION: ACTIONS.NO,
      FORM,
      TmpImageForm,
      ACTIONS,
      wallpaperPreview: NoImage
    };
  },
  computed: {
    ...mapGetters(["userData"]),
    userId() {
      return this.mode === "view" ? this.id : this.userData.id;
    },
    disabledForm() {
      return false;
    }
  },
  watch: {
    crudDialog(value) {
      if (!value) {
        this.FORM = { ...FORM };
        this.TmpImageForm = { ...TmpImageForm, imageSlides: [], wallpaper: "" };
        this.ACTION = ACTIONS.NO;
        this.loading = false;
      }
    }
  },
  created() {
    this.loadData();
  },
  methods: {
    async selectWallpaper(event) {
      this.TmpImageForm.wallpaper = event
        ? await this.getBase64(event, true)
        : NoImage;
    },
    selectSlides(files) {
      files.forEach(
        async file =>
          await this.TmpImageForm.imageSlides.push(
            await this.getBase64(file, true)
          )
      );
    },
    loadData() {
      this.$axios.get(`/portfolio/list/user/${this.userId}`).then(r => {
        this.portfolio = [...r.data.data.content];
      });
    },
    viewPortfolio(pItem, event) {
      this.pItem = { ...this.pItem, ...pItem };
      this.viewDialog = true;
    },
    addPortFolio() {
      this.ACTION = ACTIONS.CREATE;
      this.crudDialog = true;
    },
    editPortfolio(pItem) {
      this.FORM = { ...pItem };
      this.ACTION = ACTIONS.EDIT;
      this.crudDialog = true;
    },
    deletePortfolio(pItem) {
      this.FORM = { ...pItem, wallpaper: [] };
      this.ACTION = ACTIONS.DELETE;
      this.crudDialog = true;
    },
    getBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = e => resolve(e.target.result);
        reader.onerror = error => reject(error);
      });
    },
    async storeAction() {
      if (!this.disabledForm) {
        this.loading = true;
        const wallpaper = await this.TmpImageForm.wallpaper.replace(
          /^data:image\/[a-z]+;base64,/,
          ""
        );
        const slides = await this.TmpImageForm.imageSlides.map(slide =>
          slide.replace(/^data:image\/[a-z]+;base64,/, "")
        );

        this.$axios
          .post("/portfolio/add", {
            label: this.FORM.label,
            description: this.FORM.description,
            wallpaper: wallpaper,
            imageSlides: [...slides]
          })
          .then(() => {
            this.loading = false;
            this.crudDialog = false;
            this.FORM = { ...this.FORM, ...FORM };
            this.TmpImageForm = { ...this.TmpImageForm, ...TmpImageForm };
            this.ACTION = ACTIONS.NO;
            this.loadData();
          })
          .catch(() => {
            this.loading = false;
          });
      }
    },
    async updateAction() {
      if (!this.disabledForm) {
        this.loading = true;
        const wallpaper =
          TmpImageForm.wallpaper !== ""
            ? await this.TmpImageForm.wallpaper.replace(
                /^data:image\/[a-z]+;base64,/,
                ""
              )
            : this.FORM.wallpaper;
        const slides =
          TmpImageForm.imageSlides.length !== 0
            ? await this.TmpImageForm.imageSlides.map(slide =>
                slide.replace(/^data:image\/[a-z]+;base64,/, "")
              )
            : this.FORM.imageSlides;

        this.$axios
          .put(`/portfolio/${this.FORM.id}/update`, {
            label: this.FORM.label,
            description: this.FORM.description,
            wallpaper: wallpaper,
            imageSlides: [...slides]
          })
          .then(() => {
            this.loading = false;
            this.crudDialog = false;
            this.FORM = { ...this.FORM, ...FORM };
            this.ACTION = ACTIONS.NO;
            this.loadData();
          })
          .catch(() => {
            this.loading = false;
          });
      }
    },
    async destroyAction() {
      this.$axios
        .delete(`/portfolio/${this.FORM.id}/delete`)
        .then(() => {
          this.loading = false;
          this.crudDialog = false;
          this.FORM = { ...this.FORM, ...FORM };
          this.ACTION = ACTIONS.NO;
          this.loadData();
        })
        .catch(() => {
          this.loading = false;
        });
    }
  }
};
</script>
