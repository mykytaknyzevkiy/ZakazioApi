<template>
  <v-card flat>
    <v-card-title>Паспортные данные</v-card-title>
    <v-divider />
    <v-card-text v-if="Object.keys(passport).length > 0">
      <v-row>
        <v-col>
          <div>Серия: {{ passport.serial }}</div>
          <div>Номер: {{ passport.number }}</div>
          <div>Дата выдачи: {{ passport.date_begin }}</div>
          <div>ИП: {{ passport.taxID }}</div></v-col
        >

        <v-col>
          <v-img
            contain
            max-height="150"
            max-width="250"
            :src="`${storageUrl}/${passport.files[0]}`"
          />
        </v-col>
        <v-col>
          <v-img
            contain
            max-height="150"
            max-width="250"
            :src="`${storageUrl}/${passport.files[1]}`"
          />
        </v-col>
      </v-row>
    </v-card-text>
    <template v-else><no-content /></template>
  </v-card>
</template>

<script>
import NoContent from "@/components/NoContent";
export default {
  name: "ProfilePassport",
  components: { NoContent },
  props: {
    passport: {
      type: Object
    }
  }
};
</script>
