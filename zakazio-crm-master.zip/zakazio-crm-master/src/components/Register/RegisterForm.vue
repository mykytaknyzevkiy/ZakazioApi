<template>
  <v-card flat>
    <v-form ref="form" lazy-validation @submit="stepSubmit">
      <v-card-text class="pt-6 pb-0 px-0">
        <template v-if="step === steps.PHONE">
          <v-text-field
            v-model="FORM.phoneNumber"
            placeholder="79520650966"
            type="number"
            label="телефон"
            outlined
            prepend-inner-icon="mdi-phone"
            :disabled="step !== steps.PHONE"
            :rules="[v => !!v]"
            :error-messages="phoneNumberErrors"
          />
        </template>
        <template v-if="step === steps.SMS">
          <v-text-field
            v-model="FORM.smsCode"
            placeholder=" "
            type="number"
            label="смс-код"
            prepend-inner-icon="mdi-message-processing-outline"
            outlined
            :rules="[
              v => !!v || '',
              v => v.length === 4 || 'Код сообщения из 4 цифр'
            ]"
            :error-messages="smsCodeErrors"
          />
        </template>
        <template v-if="step === steps.FINISH">
          <v-text-field
            v-model="FORM.firstName"
            label="Имя"
            placeholder=" "
            :rules="[v => !!v]"
            outlined
          />
          <v-text-field
            v-model="FORM.lastName"
            label="Фамилия"
            placeholder=" "
            :rules="[v => !!v]"
            outlined
          />
          <v-text-field
            v-model="FORM.middleName"
            label="Отчество"
            placeholder=" "
            :rules="[v => !!v]"
            outlined
          />
          <v-text-field
            v-model="FORM.email"
            label="Электронная почта"
            placeholder=" "
            :error-messages="emailErrors"
            prepend-inner-icon="mdi-email-outline"
            :rules="[
              v => !!v || '',
              v =>
                /.+@.+\..+/.test(v) ||
                'E-mail должен быть в правильном формате.'
            ]"
            outlined
          />
          <v-text-field
            v-model="FORM.password"
            label="Пароль"
            placeholder=" "
            :rules="[v => !!v]"
            type="password"
            prepend-inner-icon="mdi-form-textbox-password"
            outlined
          />
          <v-text-field
            v-model="FORM.password"
            label="Повтор пароля"
            placeholder=" "
            :rules="[v => !!v]"
            type="password"
            outlined
            prepend-inner-icon="mdi-form-textbox-password"
          />
        </template>
        <template v-if="step === steps.DONE">
          <v-alert dense type="info" icon="mdi-check">
            Регистрация завершена.
          </v-alert>
        </template>
      </v-card-text>
      <v-card-actions class="py-4 px-0 d-flex align-center justify-center">
        <v-btn
          v-if="step !== steps.DONE"
          :loading="loading"
          depressed
          type="submit"
          class="primary"
          x-large
          rounded
          @click.prevent="stepSubmit"
        >
          {{ processInfo.btnText }}
        </v-btn>
        <v-btn
          v-if="step === steps.SMS || step === steps.FINISH"
          type="reset"
          text
          @click.prevent="$emit('resetProcess')"
          >Отмена</v-btn
        >
        <v-btn to="/login" text>
          Вход
        </v-btn>
      </v-card-actions>
    </v-form>
  </v-card>
</template>

<script>
import Bus from "@/main";

const FORM = {
  phoneNumber: "",
  smsCode: "",
  email: "",
  password: "",
  firstName: "",
  lastName: "",
  middleName: "",
  user: true,
  token: ""
};

export default {
  name: "RegisterForm",
  props: {
    errors: {
      type: Array
    },
    steps: {
      type: Object
    },
    step: {
      type: String
    },
    progress: {
      type: Number
    }
  },

  data() {
    return {
      loading: false,
      FORM: { ...FORM }
    };
  },
  computed: {
    processInfo() {
      if (this.step === this.steps.PHONE) {
        return { percent: 0, btnText: "Далее", step: 1 };
      } else if (this.step === this.steps.SMS) {
        return { percent: 33, btnText: "Далее", step: 2 };
      } else if (this.step === this.steps.DONE) {
        return { percent: 100, btnText: "", step: 3 };
      }
      return { percent: 66, btnText: "Зарегистрироваться", step: 3 };
    },
    phoneNumberErrors() {
      return this.errors.reduce(
        (acc, curr) =>
          curr.field === "phoneNumber" ? `${acc} ${curr.text}` : acc,
        ""
      );
    },
    smsCodeErrors() {
      return this.errors.reduce(
        (acc, curr) => (curr.field === "smsCode" ? `${acc} ${curr.text}` : acc),
        ""
      );
    },
    emailErrors() {
      return this.errors.reduce(
        (acc, curr) => (curr.field === "email" ? `${acc} ${curr.text}` : acc),
        ""
      );
    }
  },
  created() {
    Bus.$on("clientRegisterPhoneDone", data => {
      this.loading = false;
      this.FORM.token = data.data.token;
    });
    Bus.$on("clientRegisterSMSDone", data => {
      this.FORM.token = data.data.token;
    });
    Bus.$on("clientRegisterDone", () => {
      this.loading = false;
    });
    Bus.$on("clientRegisterPhoneFailed", () => {
      console.log("clientRegisterPhoneFailed");
      this.loading = false;
    });
    Bus.$on("clientRegisterSMSFailed", () => {
      this.loading = false;
    });
    Bus.$on("setFormData", data => {
      console.log(data);
      this.FORM = { ...this.FORM, ...data };
    });
    Bus.$on("startCounter", () => {});
  },
  beforeDestroy() {
    Bus.$off("clientRegisterPhoneDone");
    Bus.$off("clientRegisterSMSDone");
    Bus.$off("clientRegisterDone");
    Bus.$off("clientRegisterPhoneFailed");
    Bus.$off("clientRegisterSMSFailed");
    Bus.$off("setFormData");
  },
  methods: {
    stepSubmit() {
      console.log("mdi-message-processing-outline");
      if (this.$refs.form.validate()) {
        if (this.step === this.steps.PHONE) {
          return this.registerPhone();
        }
        if (this.step === this.steps.SMS) {
          return this.registerSMS();
        }
        if (this.step === this.steps.FINISH) {
          return this.register();
        }
      }
    },
    registerPhone() {
      this.loading = true;
      this.$emit("registerPhone", {
        phoneNumber: this.FORM.phoneNumber
      });
    },
    registerSMS() {
      this.$emit("registerSMS", {
        phoneNumber: this.FORM.phoneNumber,
        smsCode: this.FORM.smsCode,
        token: this.FORM.token
      });
    },
    register() {
      this.$emit("register", this.FORM);
    }
  }
};
</script>
