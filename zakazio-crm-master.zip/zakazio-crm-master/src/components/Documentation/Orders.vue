<template>
  <v-card outlined>
    <v-card-title>Создание заказа</v-card-title>
    <v-divider />
    <v-card-text>
      <p>Адрес запроса:</p>
      <prism language="http" :code="url" />
      <p>Пример запроса:</p>
      <prism language="http" :code="response" />
      <p>Тело запроса:</p>
      <prism language="json" :code="body" />
    </v-card-text>
  </v-card>
</template>

<script>
import Prism from "vue-prism-component";
import "prismjs/components/prism-json";
import "prismjs/components/prism-http";
export default {
  name: "Orders",
  components: {
    Prism
  },
  props: {
    apiUrl: {
      type: String
    },
    appKey: {
      type: String
    }
  },
  data() {
    return {
      url: `${this.apiUrl}/order/add`,
      body: `{
    "category" : {
        "id": "ff80808174cc0bd10174cc18e8a50002"
    },
    "client": {
        "phoneNumber": "+380666131032",
        "firstName": "Client 3",
        "lastName": "Clienter",
        "midleName": "",
        "email": "test_client@n.ua"
    },
    "content": "Build new house"
}`,
      response: `curl --location --request POST '${this.apiUrl}/order/add' \\
--header 'key: ${this.appKey}' \\
--data-raw '{
    "category" : {
        "id": "ff80808174cc0bd10174cc18e8a50002"
    },
    "client": {
        "phoneNumber": "+380666131032",
        "firstName": "Client 3",
        "lastName": "Clienter",
        "midleName": "",
        "email": "test_client@n.ua"
    },
    "content": "Build new house"
}'`
    };
  }
};
</script>

<style scoped></style>
