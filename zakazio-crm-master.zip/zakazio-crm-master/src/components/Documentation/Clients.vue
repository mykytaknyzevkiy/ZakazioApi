<template>
  <v-card outlined>
    <v-card-title>Создание клиента</v-card-title>
    <v-divider />
    <v-card-text>
      <p>По этом адресу вы можете получать список своих клиентов</p>
      <prism language="http" :code="url" />
      <p>Пример запроса</p>
      <prism language="http" :code="request" />
      <p>Пример ответа</p>
      <prism language="json" :code="response" />
    </v-card-text>
  </v-card>
</template>

<script>
import Prism from "vue-prism-component";
import "prismjs/components/prism-json";
import "prismjs/components/prism-http";
export default {
  name: "Clients",
  components: {
    Prism
  },
  props: {
    apiUrl: {
      type: String
    },
    appKey: {
      type: String
    }
  },
  data() {
    return {
      url: `${this.apiUrl}/client/list?page=1&size=10`,
      request: `curl --location --request GET '${this.apiUrl}/client/list?page=1&size=10' \\
--header 'key: ${this.appKey}'`,
      response: `{
  "version": "24",
  "success": true,
  "error": null,
  "data": {
    "pageNo": 1,
    "maxPages": 1,
    "items": [
      {
        "id": "ff80808174cc0bd10174cc19a09d0006",
        "firstName": "Client",
        "lastName": "Clienter",
        "middleName": "",
        "phoneNumber": "+380666131032",
        "email": "test_client@n.ua"
      }
    ]
  }
}`
    };
  }
};
</script>

<style scoped></style>
