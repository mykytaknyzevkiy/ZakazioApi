<template>
  <v-card outlined>
    <v-card-title>Получение категорий</v-card-title>
    <v-divider />
    <v-card-text>
      <p>
        По этом адресу вы можете получать список доступных вам категорий
        заказов.
      </p>
      <prism language="http" :code="url" />
      <p>Пример запроса:</p>
      <prism :code="request" language="http" />
      <p>Пример ответа:</p>
      <prism :code="response" language="json" />
    </v-card-text>
  </v-card>
</template>

<script>
import Prism from "vue-prism-component";
import "prismjs/components/prism-json";
import "prismjs/components/prism-http";
export default {
  name: "Categories",
  components: {
    Prism
  },
  props: {
    apiUrl: {
      type: String
    },
    appKey: {
      type: String
    }
  },
  data() {
    return {
      url: `${this.apiUrl}/category/list?page=1&size=10`,
      request: `curl --location --request GET '${this.apiUrl}/category/list?page=1&size=10' \\
--header 'key: ${this.appKey}'`,
      response: `{
  "version": "24",
  "success": true,
  "error": null,
  "data": {
    "pageNo": 1,
    "maxPages": 1,
    "items": [
      {
        "id": "ff80808174cc0bd10174cc18e8a50002",
        "active": true,
        "name": "Category test",
        "image": null
      }
    ]
  }
}`
    };
  }
};
</script>
