<template>
  <v-card outlined>
    <v-card-title>Регистрация исполнителя</v-card-title>
    <v-divider />
    <v-card-text>
      <p>Создание исполнителя от имени партнера происходит в три шага:</p>
      <h2 class="mb-3">Шаг первый:</h2>
      <p class="mb-3">
        Отправляем запрос на регистрацию номера телефона в системе по адресу:
        <kbd>{{ stepOneUrl }}</kbd
        >. Пример запроса:
      </p>
      <prism :code="stepOneCurl"></prism>
      <p class="mb-3">Тело запроса:</p>
      <prism :code="stepOneRequestBody" language="json"></prism>
      <v-divider class="my-3" />
      <h2 class="mb-3">Шаг второй:</h2>
      <p class="mb-3">
        Отправляем смс-код подтверждения номера по адресу:
        <kbd>{{ stepOneUrl }}</kbd
        >. Пример запроса:
      </p>
      <prism :code="stepTwoCurl"></prism>
      <p class="mb-3">Тело запроса:</p>
      <prism :code="stepTwoRequestBody" language="json"></prism>
      <v-divider class="my-3" />
      <h2 class="mb-3">Шаг третий:</h2>
      <p class="mb-3">
        Отправляем данные для регистрации исполнителя:
        <kbd>{{ stepThreeUrl }}</kbd
        >. Пример запроса:
      </p>
      <prism :code="stepThreeCurl"></prism>
      <p class="mb-3">Тело запроса:</p>
      <prism :code="stepThreeRequestBody" language="json"></prism>
    </v-card-text>
  </v-card>
</template>

<script>
import Prism from "vue-prism-component";
import "prismjs/components/prism-json";
import "prismjs/components/prism-http";
export default {
  name: "Executors",
  components: {
    Prism
  },
  props: {
    apiUrl: {
      type: String
    },
    appKey: {
      type: String
    }
  },
  data() {
    return {
      stepOneUrl: "/executor/signup/phone",
      stepThreeUrl: "/executor/signup",
      stepOneCurl: `curl --location --request POST '${this.stepOneUrl}' \\
--header 'key: ${this.appKey}' \\
--data-raw '{
    "phone": "+3800000000"
}'`,
      stepOneRequestBody: `{
    "phone": "+3800000000"
}`,
      stepTwoCurl: `curl --location --request POST '${this.stepOneUrl}' \\
--header 'key: ${this.appKey}' \\
--data-raw '{
    "phone": "+3800000000",
    "code": "555"
}'`,
      stepTwoRequestBody: `{
    "phone": "+3800000000",
    "code": "555"
}`,
      stepThreeCurl: `curl --location --request POST '${this.stepThreeUrl}' \\
--header 'key: ${this.appKey}' \\
--data-raw '{
    "phoneVerificationId": "ff80808175289080017528919eb00001",
    "firstName": "My",
    "lastName": "Executor",
    "middleName": "One",
    "email": "executor_one@n.ua",
    "password": "1234"
}'`,
      stepThreeRequestBody: `{
    "phoneVerificationId": "ff80808175289080017528919eb00001",
    "firstName": "My",
    "lastName": "Executor",
    "middleName": "One",
    "email": "executor_one@n.ua",
    "password": "1234"
}`
    };
  }
};
</script>

<style scoped></style>
